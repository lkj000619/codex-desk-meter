import hashlib
import json
import re
import subprocess
import wave
from pathlib import Path
import numpy as np

base = Path('C:/Espressif/benchmark-remediation/hardware-r21-20260929')
out = base / 'audio-click-recheck-20260929'
out.mkdir(exist_ok=True)
source = base / 'user-media-01/video.mp4'
ffmpeg = Path('C:/Espressif/tmp/codex-video-tools/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe')
wav = out / 'original-audio-mono-48k.wav'
command = [str(ffmpeg), '-hide_banner', '-i', str(source), '-map', '0:a:0', '-vn',
           '-af', 'ashowinfo', '-ac', '1', '-ar', '48000', '-c:a', 'pcm_s16le', '-y', str(wav)]
result = subprocess.run(command, capture_output=True)
(out / 'audio-extraction-stderr.txt').write_bytes(result.stderr)
if result.returncode:
    raise RuntimeError('Audio extraction failed')
log = result.stderr.decode(errors='replace')
audio_frames = [(int(n), int(pts), int(samples)) for n, pts, samples in re.findall(
    r'\bn:(\d+)\s+pts:(\d+)\s+pts_time:[\d.]+.*?nb_samples:(\d+)', log)]
assert audio_frames
audio_start = audio_frames[0][1] / 48000
running_samples = 0
for n, pts, samples in audio_frames:
    assert pts == audio_frames[0][1] + running_samples
    running_samples += samples
with wave.open(str(wav)) as handle:
    assert handle.getframerate() == 48000 and handle.getnchannels() == 1
    values = np.frombuffer(handle.readframes(handle.getnframes()), dtype='<i2').astype(np.float64) / 32768
assert len(values) == running_samples

differences = np.diff(values, prepend=values[0])
count = len(differences) // 48
energy = np.sqrt(np.mean(differences[:count * 48].reshape(count, 48) ** 2, axis=1))
windows = [(6.2, 7.4), (12.0, 13.2), (20.0, 21.4)]
records = []
for index, (start, end) in enumerate(windows, 1):
    excerpt = out / f'click-window-{index}.mp3'
    command = [str(ffmpeg), '-hide_banner', '-i', str(source), '-map', '0:a:0',
               '-ss', str(start), '-t', str(end - start), '-ac', '1', '-ar', '16000',
               '-c:a', 'libmp3lame', '-b:a', '32k', '-y', str(excerpt)]
    result = subprocess.run(command, capture_output=True)
    assert result.returncode == 0
    candidates = []
    start_ms = round((start - audio_start) * 1000)
    local = energy[start_ms:round((end - audio_start) * 1000)]
    for n in np.argsort(local)[::-1]:
        timestamp = audio_start + (start_ms + int(n)) / 1000
        if all(abs(timestamp - existing['peak_time_seconds']) >= .035 for existing in candidates):
            candidates.append({'peak_time_seconds': round(timestamp, 4), 'differenced_rms_1ms': float(local[n])})
        if len(candidates) == 12:
            break
    candidates.sort(key=lambda candidate: candidate['peak_time_seconds'])
    records.append({'window': [start, end], 'excerpt': excerpt.name,
                    'candidate_transients': candidates})

record = {'original_video_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'audio_start_pts_seconds': audio_start,
          'audio_sample_rate': 48000, 'audio_samples': len(values),
          'audio_frame_count': len(audio_frames),
          'extraction': 'Original AAC decoded to 48k mono PCM. Video timeline = PCM sample index/48000 + original first audio PTS; continuity and total samples verified. MP3 excerpts are audition aids only.',
          'detector': '1ms RMS of first-differenced PCM; top peaks separated by at least 35ms, candidate selection only, not switch-press classification',
          'windows': records,
          'files_sha256': {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                           for path in out.iterdir() if path.is_file()}}
(out / 'audio-analysis-record.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'audio_start': record['audio_start_pts_seconds'], 'sample_rate': 48000,
                  'windows': records}))
