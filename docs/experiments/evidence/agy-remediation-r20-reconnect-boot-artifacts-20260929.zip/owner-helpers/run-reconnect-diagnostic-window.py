import datetime
import hashlib
import json
import subprocess
import sys
import threading
import time
from pathlib import Path

evaluation = Path(sys.argv[1]).resolve()
base = Path('C:/Espressif/benchmark-remediation')
assert evaluation.parent == base
metadata = json.loads((evaluation / 'evaluation.json').read_text(encoding='utf-8'))
checkout = evaluation / 'checkout'
hardware = base / 'hardware-r20-20260929'
output = hardware / 'reported-reconnect-boot-diagnosis'
assert not output.exists()
output.mkdir()
store = hardware / 'actual-cli-tests/sequence-store'
alias = 'esp32s3-288485b08518'
sys.path.insert(0, str(checkout / 'scripts'))
import host_device_pipeline as candidate

argv = [sys.executable, str(checkout / 'scripts/run-host-device-pipeline.py'), '--candidate', '--device-alias', alias, '--sequence-store-dir', str(store), '--send', '--port', 'COM3', '--max-cycles', '61', '--poll-interval', '5', '--output', str(output / 'last-frame.bin')]
report = {
    'run_id': metadata['run_id'], 'implementation_commit': metadata['implementation_commit'],
    'operator_product_edits': False, 'ranking_eligible': False, 'product_pass': False,
    'hardware_accessed': True,
    'owner_report': 'usb 단절 시, rst 버튼, 혹은 재전원 인가 시 정보가 넘어오지않는것으로 보임. boot 버튼은 2회 누렸을때와 약 500ms 이상 눌렸을 때 페이지가 넘어감. 가끔 1회 눌렸을때도 넘어감.',
    'precondition': 'Process inventory showed no active PC sender; COM3 enumerated. Start unchanged candidate periodic sender on existing durable store, without resetting or initializing board.',
    'scope': 'Five-second diagnostic polling, finite61cycles (~5min). Actual production CLI unchanged; host frame writes alone are not proof of physical LCD or device receipt.',
    'argv': argv, 'initial_next_sequence': candidate.PersistentSequenceStore(store).get_current_sequence(alias),
    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'phase': 'running',
}
stop = threading.Event()
frames = []
def monitor():
    previous = None
    while not stop.is_set():
        path = output / 'last-frame.bin'
        if path.exists():
            try:
                data = path.read_bytes()
                frame = json.loads(data)
            except (OSError, json.JSONDecodeError):
                pass
            else:
                if frame['sequence'] != previous:
                    previous = frame['sequence']
                    frames.append({'sequence': previous, 'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sha256': hashlib.sha256(data).hexdigest()})
                    (output / f'sequence-{previous}.bin').write_bytes(data)
                    (output / 'observed-frames.json').write_text(json.dumps(frames, indent=2) + '\n', encoding='utf-8')
        stop.wait(0.1)
thread = threading.Thread(target=monitor)
thread.start()
process = None
errors = []
try:
    with (output / 'stdout.txt').open('wb') as stdout, (output / 'stderr.txt').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=checkout, stdout=stdout, stderr=stderr)
        report['sender_pid'] = process.pid
        (output / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'phase': 'running', 'sender_pid': process.pid, 'initial_next_sequence': report['initial_next_sequence']}), flush=True)
        process.wait(timeout=420)
except Exception as exc:
    errors.append(repr(exc))
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        process.wait(timeout=10)
    stop.set()
    thread.join()
    report.update(phase='ended', exit_code=process.returncode if process else None, errors=errors, observed_frames=frames, next_sequence=candidate.PersistentSequenceStore(store).get_current_sequence(alias), finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (output / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'phase': 'ended', 'exit_code': report['exit_code'], 'observed_frame_count': len(frames), 'next_sequence': report['next_sequence'], 'errors': errors}), flush=True)
