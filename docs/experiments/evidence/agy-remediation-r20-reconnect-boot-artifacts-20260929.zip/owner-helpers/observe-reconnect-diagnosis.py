import datetime
import hashlib
import json
import sys
import time
from pathlib import Path

base = Path('C:/Espressif/benchmark-remediation')
evaluation = base / 'evaluation-r20-20260928'
hardware = base / 'hardware-r20-20260929'
window = hardware / 'reported-reconnect-boot-diagnosis'
metadata = json.loads((evaluation / 'evaluation.json').read_text(encoding='utf-8'))
sender = json.loads((window / 'report.json').read_text(encoding='utf-8'))
assert sender['phase'] == 'ended' and sender['exit_code'] == 0
out = hardware / 'reported-reconnect-post-owner-observation'
assert not out.exists()
out.mkdir()
sys.path.insert(0, str(evaluation / 'checkout/scripts'))
import host_device_pipeline as candidate
report = {'run_id': metadata['run_id'], 'implementation_commit': metadata['implementation_commit'], 'operator_product_edits': False, 'ranking_eligible': False, 'product_pass': False, 'purpose': 'Read existing device logs after diagnostic sender closes; no write/reset/reinitialization/firmware upload.', 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
data = bytearray()
errors = []
session = None
try:
    session = candidate.open_owner_serial('COM3')
    report.update(dtr=session.dtr, rts=session.rts)
    started = time.monotonic()
    while time.monotonic() - started < 3:
        data.extend(session.read(4096))
except Exception as exc:
    errors.append(repr(exc))
finally:
    if session is not None:
        session.close()
    (out / 'device-log.txt').write_bytes(data)
    report.update(errors=errors, finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), bytes_observed=len(data), device_log=data.decode('utf-8', errors='replace'), device_log_sha256=hashlib.sha256(data).hexdigest())
    (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report))
