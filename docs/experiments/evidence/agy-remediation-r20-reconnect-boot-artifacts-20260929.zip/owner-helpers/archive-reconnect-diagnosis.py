import datetime
import hashlib
import json
import sys
import zipfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
assert root == Path('C:/Users/이광진/orca/codex-desk-meter')
base = Path('C:/Espressif/benchmark-remediation')
evaluation = base / 'evaluation-r20-20260928'
metadata = json.loads((evaluation / 'evaluation.json').read_text(encoding='utf-8'))
hardware = base / 'hardware-r20-20260929'
output = hardware / 'reported-reconnect-boot-diagnosis'
observation = hardware / 'reported-reconnect-post-owner-observation'
evidence = root / 'docs/experiments/evidence'
review_path = evidence / 'agy-remediation-r20-reconnect-boot-diagnosis-20260929.json'
archive_path = evidence / 'agy-remediation-r20-reconnect-boot-artifacts-20260929.zip'
receipt_path = evidence / 'agy-remediation-r20-reconnect-boot-artifacts-20260929.json'
assert not any(p.exists() for p in [review_path, archive_path, receipt_path])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sender = json.loads((output / 'report.json').read_text(encoding='utf-8'))
summary = json.loads((output / 'stderr.txt').read_text(encoding='utf-8').splitlines()[-1])
native = json.loads((observation / 'report.json').read_text(encoding='utf-8'))
assert sender['phase'] == 'ended' and sender['exit_code'] == 0 and not sender['errors']
assert summary['cycles_run'] == 61 and summary['sequence'] == 90 and sender['next_sequence'] == 91
assert not any(sha(evaluation / 'checkout' / name) != expected for name, expected in metadata['source_file_hashes'].items())
assert not any(sha(evaluation / 'checkout/build' / name) != expected for name, expected in metadata['binary_hashes'].items())
review = {
    'run_id': metadata['run_id'], 'implementation_commit': metadata['implementation_commit'],
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'ranking_eligible': False, 'product_pass': False, 'operator_product_edits': False,
    'classification': 'owner_reported_rst_recovery_and_boot_input_investigation',
    'initial_process_inventory': 'No running run-host-device-pipeline/benchmark-remediation sender process, COM3 enumerated; readonly Windows process/PnP query.',
    'owner_report': sender['owner_report'],
    'owner_could_confirm_provider_change_on_single_boot_press': False,
    'owner_followup_verbatim': '10초 안에 값이 돌아옴. 약 3초 걸림. boot 짧은 입력은 될때가 있고 안될대가 있음. 내가 봤을때는 boot 스위치를 길게 혹은 짧게 2번 누르고 난 뒤 빠르게 1회 누르면 넘어가는 느낌이였음. 뭐 문제가 될 것을 아니니까.',
    'rst_recovery': {'verdict': 'owner_observed_recovery_while_sender_running', 'approximate_seconds': 3, 'method': 'Owner text observation, not synchronized instrument/video timing. Five-second diagnostic periodic schedule includes wait to next send; not receive-to-LCD <=2s measurement.'},
    'boot_short_input': {'verdict': 'partial; owner reports intermittent missed response', 'source_findings': ['Sampled GPIO0 edge read in UI/render/IMU task while state lock held', 'At least50ms task sleep plus I2C/render work between samples', '200ms inter-event cooldown updates last low sample even when transition is rejected', 'Dashboard provider cycling intentionally can keep page number unchanged'], 'root_cause_scope': 'Stopped sender explains absent automatic transmissions before diagnostic run. GPIO sampling can miss a short pulse in code; exact physical source of every owner-reported miss is not yet instrumented.'},
    'actual_cable_disconnect_or_powercycle_recovery': 'not_run; follow-up did not explicitly establish either',
    'sender_report': sender, 'sender_cli_summary': summary,
    'frame_observation_limit': '61 successful CLI cycles, 60 independently sampled frame-file changes. Store29->91 reserves62 sequence numbers: at least one reservation consumed without a returned successful cycle. No individual ACK log for every cycle; do not infer exact failure trigger from sequence gap alone.',
    'post_sender_native_observation': native,
    'source_and_binary_hashes_unchanged': True,
    'board_still_running_r20': True,
    'r21_agent_started_without_runtime_feedback': True,
    'operator_launch_errors_not_agent_trials': ['Launch-gate helper invoked before preflight completion; guard rejected without starting AGY.', 'Scoped wrapper options supplied after action run; argparse rejected before changing global files or starting AGY. Correct invocation then started one r21 run.'],
}
review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
files = [(p, 'hardware/' + p.relative_to(hardware).as_posix()) for directory in [output, observation] for p in sorted(directory.iterdir()) if p.is_file()]
store = hardware / 'actual-cli-tests/sequence-store'
files += [(p, 'sequence-store-snapshot/' + p.relative_to(store).as_posix()) for p in sorted(store.rglob('*')) if p.is_file()]
files += [(base / name, 'owner-helpers/' + name) for name in ['run-reconnect-diagnostic-window.py', 'observe-reconnect-diagnosis.py', 'archive-reconnect-diagnosis.py']]
files.append((review_path, 'root-review/' + review_path.name))
entries = {}
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path, name in files:
        content = path.read_bytes()
        entries[name] = {'sha256': hashlib.sha256(content).hexdigest(), 'size': len(content)}
        archive.writestr(name, content)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for name, entry in entries.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == entry['sha256']
receipt = {'run_id': metadata['run_id'], 'ranking_eligible': False, 'product_pass': False, 'operator_product_edits': False, 'archive': archive_path.name, 'sha256': sha(archive_path), 'bytes': archive_path.stat().st_size, 'entry_count': len(entries), 'entries': entries}
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'review': review_path.name, 'archive': archive_path.name, 'sha256': receipt['sha256'], 'bytes': receipt['bytes'], 'entries': len(entries), 'next_sequence': 91}))
