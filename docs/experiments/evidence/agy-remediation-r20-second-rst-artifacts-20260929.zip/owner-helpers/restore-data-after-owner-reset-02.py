import datetime
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

evaluation = Path(sys.argv[1]).resolve()
base = Path('C:/Espressif/benchmark-remediation')
assert evaluation.parent == base
metadata = json.loads((evaluation / 'evaluation.json').read_text(encoding='utf-8'))
checkout = evaluation / 'checkout'
hardware = base / 'hardware-r20-20260929'
output = hardware / 'after-owner-confirmed-reset-02'
assert not output.exists()
output.mkdir()
store = hardware / 'actual-cli-tests/sequence-store'
alias = 'esp32s3-288485b08518'
sys.path.insert(0, str(checkout / 'scripts'))
import host_device_pipeline as candidate

report = {
    'run_id': metadata['run_id'],
    'implementation_commit': metadata['implementation_commit'],
    'operator_product_edits': False,
    'ranking_eligible': False,
    'product_pass': False,
    'hardware_accessed': True,
    'owner_statements': ['야 내가 또 리셋 눌렸어.', 'rst 버튼 눌렸어. 그래서 lcd에 값들이 안나옴'],
    'owner_reset_video': None,
    'purpose': 'Restore fixture data after second owner-reported RST using unchanged AGY CLI and existing durable store. No initialization, firmware upload or operator reset.',
    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
data = bytearray()
session = None
errors = []
try:
    initial = candidate.PersistentSequenceStore(store).get_current_sequence(alias)
    report['initial_next_sequence'] = initial
    assert initial == 28, f'Unexpected durable next sequence: {initial}'
    argv = [sys.executable, str(checkout / 'scripts/run-host-device-pipeline.py'), '--candidate', '--device-alias', alias, '--sequence-store-dir', str(store), '--send', '--port', 'COM3', '--max-cycles', '1', '--output', str(output / 'frame.bin')]
    report['argv'] = argv
    process = subprocess.run(argv, cwd=checkout, capture_output=True, timeout=30)
    (output / 'stdout.txt').write_bytes(process.stdout)
    (output / 'stderr.txt').write_bytes(process.stderr)
    report['exit_code'] = process.returncode
    assert process.returncode == 0, f'Actual sender exit {process.returncode}'
    session = candidate.open_owner_serial('COM3')
    report.update(dtr=session.dtr, rts=session.rts)
    started = time.monotonic()
    while time.monotonic() - started < 3:
        data.extend(session.read(4096))
except Exception as exc:
    errors.append(repr(exc))
finally:
    if session is not None:
        try:
            session.close()
        except Exception as exc:
            errors.append(repr(exc))
    (output / 'device-log.txt').write_bytes(data)
    try:
        report['next_sequence'] = candidate.PersistentSequenceStore(store).get_current_sequence(alias)
    except Exception as exc:
        errors.append(repr(exc))
    report.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), errors=errors, device_log=data.decode('utf-8', errors='replace'))
    report['sequence_28_accepted_in_existing_firmware_log'] = b'Accepted cdm/1 frame seq=28 ' in data
    report['observation_scope'] = 'Existing firmware log read after unmodified sender exits; no new protocol ACK and no physical LCD timing or stability measurement.'
    report['log_hashes'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir() if p.is_file()}
    (output / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=True))
sys.exit(0 if not errors and report['sequence_28_accepted_in_existing_firmware_log'] and report.get('next_sequence') == 29 else 1)
