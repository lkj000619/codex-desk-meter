import datetime
import hashlib
import json
import sys
import zipfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
assert root == Path('C:/Users/이광진/orca/codex-desk-meter')
base = Path('C:/Espressif/benchmark-remediation')
evaluation = base / 'evaluation-r20-20260928'
metadata = json.loads((evaluation / 'evaluation.json').read_text(encoding='utf-8'))
hardware = base / 'hardware-r20-20260929'
output = hardware / 'after-owner-confirmed-reset-02'
evidence = root / 'docs/experiments/evidence'
review_path = evidence / 'agy-remediation-r20-second-rst-supplement-20260929.json'
archive_path = evidence / 'agy-remediation-r20-second-rst-artifacts-20260929.zip'
receipt_path = evidence / 'agy-remediation-r20-second-rst-artifacts-20260929.json'
assert not any(p.exists() for p in [review_path, archive_path, receipt_path])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = json.loads((output / 'report.json').read_text(encoding='utf-8'))
assert report['exit_code'] == 0 and not report['errors']
assert report['sequence_28_accepted_in_existing_firmware_log'] and report['next_sequence'] == 29
source_changes = {name: sha(evaluation / 'checkout' / name) for name, expected in metadata['source_file_hashes'].items() if sha(evaluation / 'checkout' / name) != expected}
binary_changes = {name: sha(evaluation / 'checkout/build' / name) for name, expected in metadata['binary_hashes'].items() if sha(evaluation / 'checkout/build' / name) != expected}
assert not source_changes and not binary_changes
old_archive = evidence / 'agy-remediation-r20-hardware-artifacts-20260929.zip'
assert sha(old_archive) == '2d058c873ec124a5060108dcd6c0af885c545d79862a815292ef5dcd2d061449'
review = {
    'run_id': report['run_id'],
    'implementation_commit': report['implementation_commit'],
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'classification': 'second_owner_reported_rst_and_actual_cli_reception',
    'ranking_eligible': False,
    'product_pass': False,
    'operator_product_edits': False,
    'owner_statements': report['owner_statements'],
    'reset_count_scope': 'Two latest messages describe the same second reported intentional RST; no independent new video or third reset inferred.',
    'new_product_defect_established': False,
    'post_reset_restoration': report,
    'physical_lcd_restoration_directly_observed': False,
    'thirty_second_stationary_display_gate': 'pending; no new stationary video supplied',
    'source_changes_since_independent_build': source_changes,
    'binary_changes_since_independent_build': binary_changes,
    'evidence': [{'path': str(p), 'sha256': sha(p)} for p in sorted(output.iterdir()) if p.is_file()],
    'previous_sealed_records': [{'path': p.name, 'sha256': sha(p)} for p in [old_archive, evidence / 'agy-remediation-r20-hardware-review-20260929.json', evidence / 'agy-remediation-r20-rst-video-supplement-20260929.json']],
}
review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
files = [(p, 'hardware/' + p.relative_to(hardware).as_posix()) for p in sorted(output.iterdir()) if p.is_file()]
files += [(p, 'sequence-store-snapshot/' + p.relative_to(hardware / 'actual-cli-tests/sequence-store').as_posix()) for p in sorted((hardware / 'actual-cli-tests/sequence-store').rglob('*')) if p.is_file()]
files += [(base / name, 'owner-helpers/' + name) for name in ['restore-data-after-owner-reset-02.py', 'archive-second-owner-reset.py']]
files.append((review_path, 'root-review/' + review_path.name))
entries = {}
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path, name in files:
        content = path.read_bytes()
        entries[name] = {'sha256': hashlib.sha256(content).hexdigest(), 'size': len(content)}
        archive.writestr(name, content)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert sorted(archive.namelist()) == sorted(entries)
    for name, entry in entries.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == entry['sha256']
receipt = {
    'run_id': report['run_id'], 'implementation_commit': report['implementation_commit'],
    'ranking_eligible': False, 'product_pass': False, 'operator_product_edits': False,
    'archive': archive_path.name, 'sha256': sha(archive_path), 'bytes': archive_path.stat().st_size,
    'entry_count': len(entries), 'entries': entries,
    'store_snapshot_scope': 'Post-transmission snapshot; durable next sequence 29. Original prior archive remains at its earlier snapshot.',
    'previous_hardware_archive_preserved_sha256': sha(old_archive),
}
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'review': str(review_path), 'archive': str(archive_path), 'sha256': receipt['sha256'], 'bytes': receipt['bytes'], 'entries': len(entries), 'source_changes': source_changes, 'binary_changes': binary_changes}))
