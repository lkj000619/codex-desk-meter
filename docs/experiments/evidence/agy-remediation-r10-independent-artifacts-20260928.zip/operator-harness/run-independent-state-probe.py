import copy,hashlib,json,os,subprocess,sys,tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
root=Path.cwd();e=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('C:/Espressif/benchmark-remediation/evaluation-r10-20260928');c=e/'checkout';out=e/'operator-state-tests';assert not out.exists();out.mkdir()
sys.path.insert(0,str(root/'scripts'));import host_device_pipeline as oracle
ref='2026-09-10T00:04:59Z';base=json.loads((root/'experiments/fixtures/providers/codex-percent-window.json').read_text(encoding='utf-8'))
error=copy.deepcopy(base);error.update(snapshot_id='operator-error-fixture',status='error',windows=[],error_code='HTTP_500',error_reason='Synthetic error for last-good verification')
old=copy.deepcopy(base);old.update(snapshot_id='operator-old-fixture',status='stale',stale=True,observed_at='2026-09-08T00:00:00Z',last_good_at='2026-09-08T00:00:00Z')
future=copy.deepcopy(base);future.update(snapshot_id='operator-future-fixture',observed_at='2026-09-10T00:06:00Z')
paths=[]
for i,(name,snapshot) in enumerate([('fresh',base),('error',error),('old',old),('future',future)],1):
    frame=oracle.build_frame({'usage':[snapshot],'global_resets':[]},i,ref);p=out/(name+'.bin');p.write_bytes(oracle.encode_frame(frame));paths.append(p)
src=e.parent/'operator-state-probe.c';exe=out/'operator-state-probe.exe'
p=subprocess.run([os.environ.get('CC','cc'),'-I',str(c/'components/meter/include'),str(src),str(c/'build-host/libmeter_core.a'),'-o',str(exe)],capture_output=True)
(out/'compile-stdout.txt').write_bytes(p.stdout);(out/'compile-stderr.txt').write_bytes(p.stderr);assert p.returncode==0
p=subprocess.run([str(exe),*[str(x) for x in paths],ref],capture_output=True);(out/'probe-stdout.txt').write_bytes(p.stdout);(out/'probe-stderr.txt').write_bytes(p.stderr);assert p.returncode==0
cases=[json.loads(line) for line in p.stdout.splitlines()]
# Candidate PC module in a separate import namespace; inputs remain synthetic and no port is opened.
import importlib.util
spec=importlib.util.spec_from_file_location('candidate_pipeline',c/'scripts/host_device_pipeline.py');candidate=importlib.util.module_from_spec(spec);sys.modules[spec.name]=candidate;spec.loader.exec_module(candidate)
alias='operator-test-device';state_dir=out/'sequence-store';store=candidate.PersistentSequenceStore(state_dir);store.initialize_device(alias,7)
def reserve(i):
    try:return {'request':i,'sequence':candidate.PersistentSequenceStore(state_dir).reserve_next_sequence(alias)}
    except Exception as exc:return {'request':i,'error_type':type(exc).__name__,'error':str(exc)}
with ThreadPoolExecutor(max_workers=8) as pool:outcomes=list(pool.map(reserve,range(32)))
reservations=[x['sequence'] for x in outcomes if 'sequence' in x]
before_reinit=store.get_current_sequence(alias)
try:store.initialize_device(alias,1);reinitialize={'refused':False}
except Exception as exc:reinitialize={'refused':True,'error_type':type(exc).__name__,'error':str(exc)}
after_reinit=store.get_current_sequence(alias)
report={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'implementation_commit':json.loads((e/'evaluation.json').read_text(encoding='utf-8'))['implementation_commit'],'operator_test_harness_only':True,'hardware_accessed':False,'c_state_cases':cases,'sequence_reservation_outcomes':outcomes,'unique_reservation_count':len(set(reservations)),'successful_reservation_count':len(reservations),'duplicate_reservation_count':len(reservations)-len(set(reservations)),'error_count':len(outcomes)-len(reservations),'requested_reservation_count':len(outcomes),'sequence_before_reinitialize':before_reinit,'sequence_after_reinitialize':after_reinit,'reinitialization':reinitialize,'input_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'product_pass':False}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report))
