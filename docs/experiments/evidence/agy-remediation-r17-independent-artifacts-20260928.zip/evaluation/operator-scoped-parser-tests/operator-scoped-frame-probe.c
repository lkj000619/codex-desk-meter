#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "meter_parser.h"
#include "meter_transport.h"

static const char *b(int value) { return value ? "true" : "false"; }
static void number(int present, double value) { if (present) printf("%.17g", value); else printf("null"); }
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    FILE *f = fopen(argv[1], "rb"); if (!f) return 3;
    fseek(f, 0, SEEK_END); long size = ftell(f); rewind(f);
    if (size < 0 || size > 1024*1024) { fclose(f); return 4; }
    char *bytes = calloc((size_t)size + 1, 1); if (!bytes) return 5;
    fread(bytes, 1, (size_t)size, f); fclose(f);
    cdm_frame_t *frame = calloc(1, sizeof(*frame)); if (!frame) return 6;
    char error[64] = {0};
    size_t parser_len = (size_t)size;
    if (parser_len && bytes[parser_len-1] == '\n') parser_len--;
    char saved = bytes[parser_len]; bytes[parser_len] = 0;
    int ok = meter_parse_cdm_frame(bytes, parser_len, frame, error, sizeof(error));
    bytes[parser_len] = saved;
    meter_state_t *state = calloc(1, sizeof(*state)); if (!state) return 7;
    meter_state_init(state);
    meter_transport_t transport; meter_transport_init(&transport, state);
    meter_transport_process_bytes(&transport, (const uint8_t *)bytes, (size_t)size, argv[2]);
    printf("{\"frame_size_bytes\":%zu,\"parser_ok\":%s,\"parser_error\":\"%s\",\"usage_count\":%d,\"accepted_frames\":%u,\"rejected_frames\":%u,\"active_provider\":\"%s\",\"active_stale\":%s,\"parsed_usage\":[", sizeof(*frame), b(ok), error, frame->usage_count, (unsigned)state->accepted_frames, (unsigned)state->rejected_frames, state->active_usage.provider_id, b(state->active_usage.stale));
    for (int i = 0; ok && i < frame->usage_count; i++) {
        usage_snapshot_t *u = &frame->usage[i];
        if (i) printf(",");
        printf("{\"provider_id\":\"%s\",\"agent_id\":\"%s\",\"host_id\":\"%s\",\"metric_kind\":%d,\"unit\":%d,\"status\":%d,\"stale\":%s,\"observed_at\":\"%s\",\"window_count\":%d,\"windows\":[", u->provider_id,u->agent_id,u->host_id,(int)u->metric_kind,(int)u->unit,(int)u->status,b(u->stale),u->observed_at,u->window_count);
        for (int w = 0; w < u->window_count; w++) {
            quota_window_t *v=&u->windows[w]; if(w) printf(",");
            printf("{\"window_id\":\"%s\",\"percent_used\":",v->window_id); number(v->has_percent_used,v->percent_used);
            printf(",\"percent_remaining\":");number(v->has_percent_remaining,v->percent_remaining);
            printf(",\"used_units\":");number(v->has_used_units,v->used_units);
            printf(",\"remaining_units\":");number(v->has_remaining_units,v->remaining_units);
            printf(",\"limit_units\":");number(v->has_limit_units,v->limit_units);
            printf("}");
        }
        printf("]}");
    }
    printf("]}\n");
    free(transport.rx_buffer); free(state); free(frame); free(bytes);
    return 0;
}
