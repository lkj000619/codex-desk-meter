import sys,json
from pathlib import Path
r=Path(__file__).resolve().parent
sys.path.insert(0,"C:/Espressif/benchmark-remediation/20260928-agy-remediation-r17/checkout/scripts")
import benchmark as b
p=b.read(Path("C:/Espressif/benchmark-remediation/20260928-agy-remediation-r17/profile.json"))
prompt=(r/"prompt.txt").read_bytes()
result=b.capture(p["argv"],r/"checkout",prompt,r,180)
try:b.inspect_antigravity_stream(r/"stdout.jsonl",expected_permission_mode=p["approval_policy"],expected_model=p["model"]);b.check_antigravity_stderr(r/"stderr.txt")
except ValueError as exc:result.update(status="environment_failed",reason=str(exc))
b.save(r/"result.json",result);b.save(r/"usage.json",b.telemetry(r/"stdout.jsonl","antigravity"));print(json.dumps(result))
sys.exit(0 if result["status"]=="completed" else 1)
