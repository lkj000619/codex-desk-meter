import hashlib,json,os,subprocess,sys
from pathlib import Path
e=Path(sys.argv[1]).resolve();c=e/'checkout';out=e/'operator-provider-tests';assert not out.exists();out.mkdir()
src=e.parent/'operator-provider-probe.c';exe=out/'probe.exe'
argv=[os.environ.get('CC','cc'),'-I',str(c/'components/meter/include'),str(src),str(c/'build-host/libmeter_core.a'),'-o',str(exe)]
p=subprocess.run(argv,capture_output=True);(out/'compile-stdout.txt').write_bytes(p.stdout);(out/'compile-stderr.txt').write_bytes(p.stderr);assert p.returncode==0
frame=e/'operator-frame-tests/canonical.bin';p=subprocess.run([str(exe),str(frame),'2026-09-10T00:04:59Z'],capture_output=True)
(out/'probe-stdout.txt').write_bytes(p.stdout);(out/'probe-stderr.txt').write_bytes(p.stderr);assert p.returncode==0
report={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'operator_product_edits':False,'hardware_accessed':False,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'frame_sha256':hashlib.sha256(frame.read_bytes()).hexdigest(),'actual':json.loads(p.stdout)}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
