import copy,hashlib,json,subprocess,sys,zlib
from pathlib import Path
root=Path.cwd();e=Path('C:/Espressif/benchmark-remediation/evaluation-r12-20260928');out=e/'operator-consistent-clock-tests';assert not out.exists();out.mkdir()
sys.path.insert(0,str(root/'scripts'));import host_device_pipeline as oracle
ref='2026-09-10T16:54:07Z';registry=oracle.FixtureRegistry.with_defaults(root,reference_time=ref)
frame=oracle.build_frame(registry.collect().payload,7,ref)
def unchecked_line(f):
 f=copy.deepcopy(f);body={k:v for k,v in f.items() if k!='integrity'}
 f['integrity']['value']=f'{zlib.crc32(json.dumps(body,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode())&0xffffffff:08X}'
 return (json.dumps(f,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode()
variants={'canonical-consistent-clock':oracle.encode_frame(frame)}
bad=copy.deepcopy(frame);bad['payload']['usage'][0]['windows'][0]['percent_used']=150
variants['invalid-percent-correct-crc']=unchecked_line(bad)
bad=copy.deepcopy(frame);bad['payload']['usage'][0]['unit']='invalid-unit'
variants['invalid-unit-correct-crc']=unchecked_line(bad)
exe=e/'operator-frame-tests/operator-frame-probe.exe';reports=[]
for name,data in variants.items():
 p=out/(name+'.bin');p.write_bytes(data)
 try:oracle.decode_frame_line(data);trusted={'accepted':True}
 except Exception as exc:trusted={'accepted':False,'error':str(exc)}
 result=subprocess.run([str(exe),str(p),ref],capture_output=True);assert result.returncode==0
 (out/(name+'-stdout.txt')).write_bytes(result.stdout);(out/(name+'-stderr.txt')).write_bytes(result.stderr)
 reports.append({'name':name,'input_sha256':hashlib.sha256(data).hexdigest(),'trusted_line':trusted,'actual':json.loads(result.stdout)})
report={'run_id':'20260928-agy-remediation-r12','reference_time':ref,'operator_product_edits':False,'hardware_accessed':False,'cases':reports}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'cases':[{'name':x['name'],'trusted_accepted':x['trusted_line']['accepted'],'parser_ok':x['actual']['parser_ok'],'accepted':x['actual']['accepted_frames'],'rejected':x['actual']['rejected_frames']} for x in reports]}))
