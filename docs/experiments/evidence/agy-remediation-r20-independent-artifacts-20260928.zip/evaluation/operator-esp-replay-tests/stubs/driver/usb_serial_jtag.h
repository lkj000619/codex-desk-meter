#pragma once
#include "freertos/FreeRTOS.h"
typedef struct{int tx_buffer_size,rx_buffer_size;}usb_serial_jtag_driver_config_t;
static inline int usb_serial_jtag_read_bytes(void*b,size_t n,int t){return 0;}
static inline int usb_serial_jtag_driver_install(const usb_serial_jtag_driver_config_t*c){return 0;}
