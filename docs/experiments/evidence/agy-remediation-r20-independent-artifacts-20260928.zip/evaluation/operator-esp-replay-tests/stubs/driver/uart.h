#pragma once
#include "freertos/FreeRTOS.h"
#define UART_NUM_0 0
#define UART_DATA_8_BITS 8
#define UART_PARITY_DISABLE 0
#define UART_STOP_BITS_1 1
#define UART_HW_FLOWCTRL_DISABLE 0
#define UART_SCLK_DEFAULT 0
typedef struct{int baud_rate,data_bits,parity,stop_bits,flow_ctrl,source_clk;}uart_config_t;
static inline int uart_read_bytes(int p,void*b,size_t n,int t){return 0;}
static inline int uart_param_config(int p,const uart_config_t*c){return 0;}
static inline int uart_driver_install(int p,int r,int t,int q,void*h,int f){return 0;}
