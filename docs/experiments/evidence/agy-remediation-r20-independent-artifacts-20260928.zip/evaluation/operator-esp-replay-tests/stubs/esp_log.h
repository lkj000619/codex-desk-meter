#pragma once
#include <stdio.h>
#define ESP_LOGI(tag,fmt,...) fprintf(stderr,fmt "\n",##__VA_ARGS__)
#define ESP_LOGW(tag,fmt,...) fprintf(stderr,fmt "\n",##__VA_ARGS__)
