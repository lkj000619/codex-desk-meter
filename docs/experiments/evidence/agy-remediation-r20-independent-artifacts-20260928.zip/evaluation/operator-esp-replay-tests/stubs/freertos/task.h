#pragma once
#include "FreeRTOS.h"
static inline void vTaskDelete(void *p){}
static inline int xTaskCreate(void (*f)(void*),const char*n,unsigned s,void*a,int p,void*h){return 1;}
