#pragma once
#include <stdint.h>
#include <stddef.h>
typedef int esp_err_t;
#define ESP_OK 0
#define pdMS_TO_TICKS(x) (x)
static inline const char *esp_err_to_name(int x){return "stub";}
