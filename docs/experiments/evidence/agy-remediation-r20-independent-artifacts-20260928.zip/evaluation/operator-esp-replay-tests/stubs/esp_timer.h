#pragma once
#include <stdint.h>
extern int64_t operator_clock_us;
static inline int64_t esp_timer_get_time(void){return operator_clock_us;}
