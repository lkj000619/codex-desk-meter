#include <stdio.h>
#include <stdlib.h>
#include "meter_transport.h"
int64_t operator_clock_us;
int main(int argc,char**argv){
 if(argc!=3)return 2;
 FILE*f=fopen(argv[1],"rb");if(!f)return 3;
 fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);
 unsigned char*b=malloc(n);fread(b,1,n,f);fclose(f);
 meter_state_t*s=calloc(1,sizeof(*s));meter_transport_t t;
 meter_state_init(s);meter_transport_init(&t,s);
 operator_clock_us=10000000;meter_transport_process_bytes(&t,b,n,argv[2]);
 long long first=s->last_update_mono_sec;
 operator_clock_us=999000000;meter_transport_process_bytes(&t,b,n,argv[2]);
 printf("{\"accepted\":%u,\"rejected\":%u,\"first_receive_mono\":%lld,\"after_duplicate_receive_mono\":%lld}\n",(unsigned)s->accepted_frames,(unsigned)s->rejected_frames,first,(long long)s->last_update_mono_sec);
 free(b);return 0;
}
