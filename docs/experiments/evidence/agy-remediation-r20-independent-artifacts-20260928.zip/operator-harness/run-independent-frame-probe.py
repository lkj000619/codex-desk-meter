import copy,hashlib,json,os,subprocess,sys,zlib
from pathlib import Path
root=Path.cwd();e=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('C:/Espressif/benchmark-remediation/evaluation-r10-20260928');c=e/'checkout';out=e/'operator-frame-tests';assert not out.exists();out.mkdir()
sys.path.insert(0,str(root/'scripts'));import host_device_pipeline as oracle
compiler=os.environ.get('CC','cc');exe=out/'operator-frame-probe.exe';src=e.parent/'operator-frame-probe.c'
p=subprocess.run([compiler,'-I',str(c/'components/meter/include'),str(src),str(c/'build-host/libmeter_core.a'),'-o',str(exe)],capture_output=True)
(out/'compile-stdout.txt').write_bytes(p.stdout);(out/'compile-stderr.txt').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode(errors='replace')
ref='2026-09-10T00:04:59Z';registry=oracle.FixtureRegistry.with_defaults(root,reference_time=ref)
payload=registry.collect().payload;frame=oracle.build_frame(payload,sequence=7,sent_at=ref);line=oracle.encode_frame(frame)
variants={'canonical':line,'crlf':line[:-1]+b'\r\n','pretty_json':(json.dumps(frame,indent=2)+'\n').encode(),'extra_newline':line+b'\n','overlong_prefix_then_valid':b'x'*65536+line,'overlong_then_delimiter_then_valid':b'x'*65536+b'\n'+line,'junk_prefix':b'junk'+line,'junk_suffix':line[:-1]+b'junk\n','invalid_utf8':line.replace(b'openai',b'open\xffai',1),'crc_mismatch':line.replace(frame['integrity']['value'].encode(),b'00000000',1),'truncated':line[:-10]+b'\n'}
variants['duplicate_protocol']=b'{"protocol":"cdm/1",'+line[1:]
extra=copy.deepcopy(frame);extra['unexpected']=True
variants['extra_envelope_key']=(json.dumps(extra,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode()
bad=copy.deepcopy(frame);bad['payload']['usage'][0]['windows'][0]['percent_used']=150
without={k:v for k,v in bad.items() if k!='integrity'}
crc=zlib.crc32(json.dumps(without,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())&0xffffffff
bad['integrity']['value']=f'{crc:08X}'
variants['schema_invalid_percent_with_correct_crc']=(json.dumps(bad,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode()
results=[]
for name,data in variants.items():
    path=out/(name+'.bin');path.write_bytes(data)
    p=subprocess.run([str(exe),str(path),ref],capture_output=True)
    (out/(name+'-stdout.txt')).write_bytes(p.stdout);(out/(name+'-stderr.txt')).write_bytes(p.stderr)
    decoded=json.loads(p.stdout) if p.returncode==0 else {'probe_exit_code':p.returncode}
    try:oracle.decode_frame_line(data);reference={'accepted':True}
    except Exception as exc:reference={'accepted':False,'error':str(exc)}
    results.append({'name':name,'input_sha256':hashlib.sha256(data).hexdigest(),'reference_valid_frame':name=='canonical','trusted_complete_line_validation':reference,'actual':decoded})
report={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'implementation_commit':json.loads((e/'evaluation.json').read_text())['implementation_commit'],'operator_test_harness_only':True,'hardware_accessed':False,'canonical_expected_provider_count':len(payload['usage']),'cases':results,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'product_pass':False}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'run_id':report['run_id'],'cases':[{'name':x['name'],'accepted':x['actual'].get('accepted_frames'),'rejected':x['actual'].get('rejected_frames'),'parser_error':x['actual'].get('parser_error'),'trusted_line_accepted':x['trusted_complete_line_validation']['accepted']} for x in results]}),flush=True)
