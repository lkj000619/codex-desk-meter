import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd();e=Path(sys.argv[1]).resolve();out=e/'operator-absolute-value-tests';assert not out.exists();out.mkdir()
sys.path.insert(0,str(root/'scripts'));import host_device_pipeline as oracle
ref='2026-09-10T00:04:59Z';cases=[]
for name in ['absolute-token-balance','mixed-percent-absolute']:
 snapshot=json.loads((root/('experiments/fixtures/providers/'+name+'.json')).read_text(encoding='utf-8'))
 data=oracle.encode_frame(oracle.build_frame({'usage':[snapshot],'global_resets':[]},7,ref));oracle.decode_frame_line(data);path=out/(name+'.bin');path.write_bytes(data)
 actual=subprocess.run([str(e/'operator-frame-tests/operator-frame-probe.exe'),str(path),ref],capture_output=True);assert actual.returncode==0
 (out/(name+'-stdout.txt')).write_bytes(actual.stdout);(out/(name+'-stderr.txt')).write_bytes(actual.stderr)
 cases.append({'name':name,'trusted_frame_valid':True,'input_sha256':hashlib.sha256(data).hexdigest(),'expected_snapshot':snapshot,'actual':json.loads(actual.stdout)})
r={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'hardware_accessed':False,'operator_product_edits':False,'reference_time':ref,'cases':cases}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps({'cases':[{'name':x['name'],'accepted':x['actual']['accepted_frames'],'parsed_usage':x['actual']['parsed_usage']} for x in cases]}))
