import hashlib,json,re,struct,subprocess,sys
from pathlib import Path
e=Path(sys.argv[1]).resolve();c=e/'checkout';out=e/'operator-target-state-stack';assert not (out/'report.json').exists();out.mkdir(exist_ok=True)
cache=(c/'build/CMakeCache.txt').read_text(encoding='utf-8')
dump=re.search(r'^CMAKE_OBJDUMP:FILEPATH=(.+)$',cache,re.M).group(1).strip()
copy=re.search(r'^CMAKE_OBJCOPY:FILEPATH=(.+)$',cache,re.M).group(1).strip()
obj=c/'build/esp-idf/meter/CMakeFiles/__idf_meter.dir/meter_state.c.obj'
p=subprocess.run([dump,'-dr',str(obj)],capture_output=True);assert p.returncode==0
(out/'state-disassembly.txt').write_bytes(p.stdout);(out/'state-disassembly-stderr.txt').write_bytes(p.stderr)
body=p.stdout.decode().split('<meter_state_process_frame>:',1)[1][:2500]
entry=int(re.search(r'entry\s+a1,\s*(0x[0-9a-fA-F]+|[0-9]+)',body).group(1),0)
extra=0;offset=None;literal_file=out/'state-literal.bin'
if 'movsp\ta1' in body[:350]:
 offset=int(re.search(r'R_XTENSA_SLOT0_OP\s+\.literal\.meter_state_process_frame\+(0x[0-9a-f]+)',body).group(1),0)
 p=subprocess.run([copy,'-O','binary','--only-section=.literal.meter_state_process_frame',str(obj),str(literal_file)],capture_output=True);assert p.returncode==0
 extra=-struct.unpack_from('<i',literal_file.read_bytes(),offset)[0];assert extra>0
task=int(re.search(r'xTaskCreate\(serial_rx_task,\s*"serial_rx_task",\s*([0-9]+)',(c/'components/meter/meter_transport.c').read_text(encoding='utf-8')).group(1))
r={'implementation_commit':json.loads((e/'evaluation.json').read_text())['implementation_commit'],'hardware_accessed':False,'operator_product_code_edits':False,'task_stack_bytes':task,'target_function':'meter_state_process_frame','entry_bytes':entry,'movsp_literal_offset':offset,'additional_stack_bytes':extra,'function_stack_bytes':entry+extra,'function_alone_exceeds_task':entry+extra>task,'call_site':'serial_rx_task -> meter_transport_process_bytes -> meter_state_process_frame','object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'disassembly_sha256':hashlib.sha256((out/'state-disassembly.txt').read_bytes()).hexdigest(),'prologue':body[:650]}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
