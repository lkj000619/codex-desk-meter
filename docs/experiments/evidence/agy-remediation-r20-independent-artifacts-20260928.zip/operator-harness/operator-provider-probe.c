#include <stdio.h>
#include <stdlib.h>
#include "meter_transport.h"
int main(int argc,char **argv){
 if(argc!=3)return 2;
 FILE*f=fopen(argv[1],"rb");if(!f)return 3;
 fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);
 unsigned char*b=malloc(n);fread(b,1,n,f);fclose(f);
 meter_state_t*s=calloc(1,sizeof(*s));meter_transport_t t;
 meter_state_init(s);meter_transport_init(&t,s);
 meter_transport_process_bytes(&t,b,n,argv[2]);
 printf("{\"accepted\":%u,\"retained_provider_count\":%d,\"providers\":[",(unsigned)s->accepted_frames,s->usage_count);
 for(int i=0;i<s->usage_count;i++){
  usage_snapshot_t*u=&s->providers_active[i];
  if(i)printf(",");
  printf("{\"provider\":\"%s\",\"agent\":\"%s\",\"host\":\"%s\",\"status\":%d,\"windows\":%d,\"has_good\":%s}",u->provider_id,u->agent_id,u->host_id,(int)u->status,u->window_count,s->providers_has_good[i]?"true":"false");
 }
 printf("],\"cycled_views\":[");
 for(int i=0;i<8;i++){
  if(i)printf(",");
  printf("{\"provider\":\"%s\",\"agent\":\"%s\",\"host\":\"%s\",\"status\":%d}",s->active_usage.provider_id,s->active_usage.agent_id,s->active_usage.host_id,(int)s->active_usage.status);
  meter_state_cycle_provider(s);
 }
 printf("]}\n");meter_transport_deinit(&t);free(s);free(b);return 0;
}
