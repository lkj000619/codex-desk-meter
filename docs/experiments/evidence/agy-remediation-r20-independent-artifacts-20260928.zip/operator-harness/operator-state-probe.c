#include <stdio.h>
#include <stdlib.h>
#include "meter_parser.h"
#include "meter_transport.h"
static void feed(meter_transport_t *t,const char *path,const char *now) {
    FILE *f=fopen(path,"rb");if(!f)exit(2);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);
    char *p=malloc((size_t)n);if(!p)exit(3);fread(p,1,(size_t)n,f);fclose(f);
    meter_transport_process_bytes(t,(const uint8_t*)p,(size_t)n,now);free(p);
}
int main(int argc,char **argv) {
    if(argc!=6)return 1;
    meter_state_t *s=calloc(1,sizeof(*s));meter_transport_t t;
    meter_state_init(s);meter_transport_init(&t,s);
    feed(&t,argv[1],argv[5]);
    int initial_good=s->last_good_usage.window_count;
    feed(&t,argv[2],argv[5]);
    printf("{\"case\":\"last_good_after_error\",\"before_windows\":%d,\"after_windows\":%d,\"active_error\":\"%s\",\"last_good_error\":\"%s\"}\n",initial_good,s->last_good_usage.window_count,s->active_usage.error_code,s->last_good_usage.error_code);
    free(t.rx_buffer);meter_state_init(s);meter_transport_init(&t,s);
    feed(&t,argv[3],argv[5]);int before=s->active_usage.stale;
    meter_state_set_last_update_mono_sec(s,10);meter_state_tick(s,11);
    printf("{\"case\":\"old_source_after_tick\",\"stale_before_tick\":%s,\"stale_after_tick\":%s}\n",before?"true":"false",s->active_usage.stale?"true":"false");
    free(t.rx_buffer);meter_state_init(s);meter_transport_init(&t,s);
    feed(&t,argv[4],argv[5]);
    printf("{\"case\":\"future_source\",\"accepted\":%u,\"rejected\":%u,\"observed_at\":\"%s\"}\n",(unsigned)s->accepted_frames,(unsigned)s->rejected_frames,s->active_usage.observed_at);
    free(t.rx_buffer);free(s);return 0;
}
