import hashlib,json,re,subprocess,sys
from pathlib import Path
e=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('C:/Espressif/benchmark-remediation/evaluation-r10-20260928');c=e/'checkout';out=e/'operator-frame-tests'
cache=(c/'build/CMakeCache.txt').read_text(encoding='utf-8');objdump=re.search(r'^CMAKE_OBJDUMP:FILEPATH=(.+)$',cache,re.M).group(1).strip()
obj=c/'build/esp-idf/meter/CMakeFiles/__idf_meter.dir/meter_transport.c.obj'
p=subprocess.run([objdump,'-d',str(obj)],capture_output=True);assert p.returncode==0
(out/'target-transport-disassembly.txt').write_bytes(p.stdout);text=p.stdout.decode()
start=text.index('<meter_transport_process_bytes>:');snippet=text[start:start+1000]
match=re.search(r'entry\s+a1,\s*(0x[0-9a-fA-F]+|[0-9]+)',snippet);assert match,snippet
allocated=int(match.group(1),0)
source=(c/'components/meter/meter_transport.c').read_text();task=re.search(r'xTaskCreate\(serial_rx_task,\s*"serial_rx_task",\s*([0-9]+)',source);assert task
report={'implementation_commit':json.loads((e/'evaluation.json').read_text())['implementation_commit'],'objdump':objdump,'target_function':'meter_transport_process_bytes','target_function_stack_allocation_bytes':allocated,'configured_serial_rx_task_stack_bytes':int(task.group(1)),'insufficient_task_stack':allocated>int(task.group(1)),'target_disassembly_sha256':hashlib.sha256(p.stdout).hexdigest(),'object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'prologue':snippet[:500],'hardware_accessed':False,'operator_product_code_edits':False}
(out/'target-stack-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
