"""Operator-only authorized deployment of the exact independently reviewed binary."""
import datetime,hashlib,json,re,subprocess,sys,time
from pathlib import Path
import serial
from serial.tools import list_ports
from esptool.reset import HardReset
e=Path(sys.argv[1]).resolve();c=e/'checkout';build=c/'build';b=e.parent
assert b==Path('C:/Espressif/benchmark-remediation')
read=lambda p:json.loads(p.read_text(encoding='utf-8'));h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
review=read(e/'operator-software-flash-gate.json');evaluation=read(e/'evaluation.json')
assert review['software_flash_allowed'] is True and review['operator_product_edits'] is False
assert review['implementation_commit']==evaluation['implementation_commit']
assert review['evaluation_manifest_sha256']==h(e/'evaluation.json')
required={'host-configure','host-build','ctest','candidate-python-tests','legacy-29','idf-set-target','idf-build','trusted-result-validation'}
assert required.issubset({x['name'] for x in evaluation['commands'] if x['exit_code']==0})
assert not evaluation.get('source_changes_after_build') and not evaluation.get('structured_result_missing')
assert all(h(c/n)==sha for n,sha in evaluation['source_file_hashes'].items())
assert all(h(build/n)==sha for n,sha in evaluation['binary_hashes'].items())
port='COM3';expected_serial='28:84:85:B0:85:18';matches=[p for p in list_ports.comports() if p.device==port and p.vid==0x303A and p.pid==0x1001 and p.serial_number.upper()==expected_serial]
assert len(matches)==1,'Expected identified board not present onCOM3'
args=read(build/'flasher_args.json');files=args['flash_files'];assert files and len(files)<=8
for offset,name in files.items():
 assert re.fullmatch(r'0x[0-9a-fA-F]+',offset) and (build/name).resolve().is_relative_to(build)
 assert (build/name).suffix=='.bin'
out=b/('hardware-'+evaluation['run_id'].rsplit('-',1)[1]+'-20260929');assert not out.exists();out.mkdir()
hashes={name:h(build/name) for name in files.values()}
argv=[sys.executable,'-m','esptool','--chip','esp32s3','--port',port,'--baud','460800','--before','default_reset','--after','hard_reset','write_flash']+args['write_flash_args']
for offset,name in files.items():argv +=[offset,name]
record={'run_id':evaluation['run_id'],'implementation_commit':evaluation['implementation_commit'],'classification':'remediation_post_run_hardware','ranking_eligible':False,'product_pass':False,'operator_product_edits':False,'user_flash_authorization':'User explicitly authorized upload earlier; resumed remaining work','operator_action':'Flash exact fresh independently evaluated AGY binary; no rebuild or source edits','port':port,'board_identity':{'vid':'303A','pid':'1001','serial':expected_serial},'started_at':now(),'file_hashes':hashes,'argv':argv,'software_gate_sha256':h(e/'operator-software-flash-gate.json')}
def save():(out/'flash-record.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save()
with (out/'flash-stdout.txt').open('wb') as stdout,(out/'flash-stderr.txt').open('wb') as stderr:
 p=subprocess.run(argv,cwd=build,stdout=stdout,stderr=stderr,timeout=120)
record.update(exit_code=p.returncode,finished_at=now(),file_hashes_after={name:h(build/name) for name in files.values()});assert record['file_hashes_after']==hashes
record['log_hashes']={n:h(out/n) for n in ['flash-stdout.txt','flash-stderr.txt']};save();assert p.returncode==0
boot={'run_id':evaluation['run_id'],'implementation_commit':evaluation['implementation_commit'],'capture_seconds':20,'started_at':now(),'port':port,'operator_reset':'Native USB HardReset followed by serial observation; this intentionally resets RAM receiver state','product_pass':False}
data=bytearray();s=serial.Serial(port=None,baudrate=115200,timeout=0.1,rtscts=False,dsrdtr=False);s.dtr=False;s.rts=False;s.port=port
try:
 s.open();HardReset(s,uses_usb=True)();start=time.monotonic()
 while time.monotonic()-start<20:data.extend(s.read(4096))
finally:s.close()
(out/'boot-serial.bin').write_bytes(data);text=data.decode('utf-8',errors='replace');(out/'boot-serial.txt').write_text(text,encoding='utf-8')
elf_sha=evaluation['binary_hashes']['codex-desk-meter.elf'];match=re.search(r'ELF file SHA256:\s*([0-9a-fA-F]+)',text)
boot.update(finished_at=now(),capture_elapsed_seconds=time.monotonic()-start,byte_count=len(data),elf_sha256=elf_sha,boot_elf_prefix=match.group(1) if match else None,boot_elf_identity_matches=bool(match and elf_sha.lower().startswith(match.group(1).lower())),log_hashes={n:h(out/n) for n in ['boot-serial.bin','boot-serial.txt']},potential_panic_markers=[x for x in ['Guru Meditation','Stack canary watchpoint triggered','stack overflow','abort() was called'] if x in text])
(out/'boot-record.json').write_text(json.dumps(boot,indent=2)+'\n',encoding='utf-8');print(json.dumps({'hardware_directory':str(out),'flash_exit_code':p.returncode,'boot':boot}))
