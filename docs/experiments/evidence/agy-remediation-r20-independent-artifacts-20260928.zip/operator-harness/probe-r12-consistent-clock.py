import copy,hashlib,json,subprocess,sys,zlib
from pathlib import Path
root=Path.cwd();e=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('C:/Espressif/benchmark-remediation/evaluation-r12-20260928');out=e/'operator-consistent-clock-tests';assert not out.exists();out.mkdir()
sys.path.insert(0,str(root/'scripts'));import host_device_pipeline as oracle
ref='2026-09-10T16:54:07Z';registry=oracle.FixtureRegistry.with_defaults(root,reference_time=ref)
frame=oracle.build_frame(registry.collect().payload,7,ref)
def unchecked_line(f):
 f=copy.deepcopy(f);body={k:v for k,v in f.items() if k!='integrity'}
 f['integrity']['value']=f'{zlib.crc32(json.dumps(body,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode())&0xffffffff:08X}'
 return (json.dumps(f,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode()
variants={'canonical-consistent-clock':oracle.encode_frame(frame)}
bad=copy.deepcopy(frame);bad['payload']['usage'][0]['windows'][0]['percent_used']=150
variants['invalid-percent-correct-crc']=unchecked_line(bad)
bad=copy.deepcopy(frame);bad['payload']['usage'][0]['unit']='invalid-unit'
variants['invalid-unit-correct-crc']=unchecked_line(bad)
bad=copy.deepcopy(frame);bad['payload']['usage'][0]['windows'][0]['percent_used']=True
variants['boolean-percent-correct-crc']=unchecked_line(bad)
bad=copy.deepcopy(frame);del bad['payload']['usage'][0]['provider_id']
variants['missing-provider-id-correct-crc']=unchecked_line(bad)
bad=copy.deepcopy(frame);bad['payload']['usage'][0]['status']='invalid-status'
variants['invalid-status-correct-crc']=unchecked_line(bad)
for name,path,value in [
 ('numeric-string',('usage',0,'windows',0,'percent_used'),'20'),
 ('negative-units',('usage',0,'windows',0,'remaining_units'),-1),
 ('missing-window-label',('usage',0,'windows',0,'label'),None),
 ('invalid-source-kind',('usage',0,'source_kind'),'invalid-source'),
 ('invalid-metric-kind',('usage',0,'metric_kind'),'invalid-metric'),
 ('numeric-stale',('usage',0,'stale'),0),
 ('invalid-provider-identity',('usage',0,'provider_id'),'BAD ID'),
 ('invalid-observed-timestamp',('usage',0,'observed_at'),'not-a-time'),
 ('extra-snapshot-property',('usage',0,'undeclared'),True),
 ('extra-window-property',('usage',0,'windows',0,'undeclared'),True),
 ('invalid-global-forecast',('global_resets',0,'forecast_24h_percent'),101),
 ('global-forecast-is-schedule',('global_resets',0,'forecast_is_schedule'),True),
 ('extra-global-property',('global_resets',0,'undeclared'),True),
]:
 bad=copy.deepcopy(frame);target=bad['payload']
 for key in path[:-1]:target=target[key]
 if name=='missing-window-label':del target[path[-1]]
 else:target[path[-1]]=value
 variants[name+'-correct-crc']=unchecked_line(bad)
for value in [0,100,None]:
 good=copy.deepcopy(frame);good['payload']['usage'][0]['windows'][0]['percent_used']=value
 variants['valid-percent-'+str(value)]=unchecked_line(good)
exe=e/'operator-frame-tests/operator-frame-probe.exe';reports=[]
for name,data in variants.items():
 p=out/(name+'.bin');p.write_bytes(data)
 try:oracle.decode_frame_line(data);trusted={'accepted':True}
 except Exception as exc:trusted={'accepted':False,'error':str(exc)}
 result=subprocess.run([str(exe),str(p),ref],capture_output=True);assert result.returncode==0
 (out/(name+'-stdout.txt')).write_bytes(result.stdout);(out/(name+'-stderr.txt')).write_bytes(result.stderr)
 reports.append({'name':name,'input_sha256':hashlib.sha256(data).hexdigest(),'trusted_line':trusted,'actual':json.loads(result.stdout)})
report={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'reference_time':ref,'operator_product_edits':False,'hardware_accessed':False,'cases':reports}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'cases':[{'name':x['name'],'trusted_accepted':x['trusted_line']['accepted'],'parser_ok':x['actual']['parser_ok'],'accepted':x['actual']['accepted_frames'],'rejected':x['actual']['rejected_frames']} for x in reports]}))
