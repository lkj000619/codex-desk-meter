import contextlib,hashlib,importlib.util,io,json,subprocess,sys,time
from pathlib import Path
root=Path.cwd();e=Path(sys.argv[1]).resolve();c=e/'checkout';out=e/'operator-sender-recovery-tests';assert not out.exists();out.mkdir()
sys.path.insert(0,str(c/'scripts'));import host_device_pipeline as candidate
spec=importlib.util.spec_from_file_location('candidate_cli',c/'scripts/run-host-device-pipeline.py');cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('trusted_pipeline',root/'scripts/host_device_pipeline.py');oracle=importlib.util.module_from_spec(spec);sys.modules[spec.name]=oracle;spec.loader.exec_module(oracle)
records=[]
class Sink:
 def __init__(self,alias,events,fail_write=False):self.alias=alias;self.events=events;self.fail_write=fail_write
 def write(self,data):
  frame=oracle.decode_frame_line(data);path=out/(self.alias+'-write-'+str(len(self.events))+'.bin');path.write_bytes(data)
  self.events.append({'event':'write','monotonic':time.monotonic(),'sequence':frame['sequence'],'bytes':len(data),'fail_write':self.fail_write,'input_sha256':hashlib.sha256(data).hexdigest()})
  if self.fail_write:raise OSError('operator synthetic post-write failure; bytes may already reach receiver')
  return len(data)
 def flush(self):pass
 def close(self):pass
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
for name in ['three-open-failures','one-write-failure']:
 store=out/(name+'-state');alias='operator-'+name;candidate.PersistentSequenceStore(store).initialize_device(alias,7);events=[];opened=[0];begin=time.monotonic()
 def factory(port):
  opened[0]+=1;events.append({'event':'open','attempt':opened[0],'monotonic':time.monotonic(),'port':port})
  if name=='three-open-failures' and opened[0]<=3:raise OSError('operator synthetic unavailable port')
  return Sink(alias,events,fail_write=name=='one-write-failure' and opened[0]==1)
 original=candidate.open_owner_serial;candidate.open_owner_serial=factory;stdout=io.StringIO();stderr=io.StringIO()
 try:
  with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):code=cli.main(['--candidate','--device-alias',alias,'--sequence-store-dir',str(store),'--send','--port','OPERATOR-MOCK','--max-cycles','2','--poll-interval','1'])
 finally:candidate.open_owner_serial=original
 (out/(name+'-stdout.txt')).write_text(stdout.getvalue(),encoding='utf-8');(out/(name+'-stderr.txt')).write_text(stderr.getvalue(),encoding='utf-8')
 records.append({'name':name,'exit_code':code,'elapsed_seconds':time.monotonic()-begin,'backend_would_be_usable_on_attempt':4 if name=='three-open-failures' else 2,'events':events,'stored_next_sequence':candidate.PersistentSequenceStore(store).get_current_sequence(alias),'write_sequences':[x['sequence'] for x in events if x['event']=='write']})
r={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'hardware_accessed':False,'operator_product_edits':False,'test_type':'Actual candidate CLI main with independently injected serial open/write failures; no product code changes, no hardware/ACK proof','cases':records}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
