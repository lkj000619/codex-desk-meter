import hashlib,json,sys,time
from pathlib import Path
e=Path(sys.argv[1]).resolve();c=e/'checkout';out=e/'operator-durable-reservation-tests';assert not out.exists();out.mkdir()
sys.path.insert(0,str(c/'scripts'));import host_device_pipeline as candidate
alias='operator-durable';store=candidate.PersistentSequenceStore(out/'state');store.initialize_device(alias,7);events=[]
original=candidate.os.fsync
def observed_fsync(fd):
 original(fd);events.append({'event':'fsync-returned','monotonic':time.monotonic()})
class Sink:
 def write(self,data):
  (out/'transmitted.bin').write_bytes(data)
  events.append({'event':'write','monotonic':time.monotonic(),'frame_sequence':json.loads(data)['sequence'],'state_at_write':json.loads(store._state_file(alias).read_text(encoding='utf-8'))})
  return len(data)
 def flush(self):pass
collector=candidate.ProductionCollector(registry=candidate.FixtureRegistry.with_defaults(c,reference_time='2026-09-10T16:54:07Z'),sequence_store=store,device_alias=alias,sink=Sink())
candidate.os.fsync=observed_fsync
try:frame,outcome=collector.collect_and_send(sent_at='2026-09-10T16:54:07Z',reference_time='2026-09-10T16:54:07Z')
finally:candidate.os.fsync=original
write=next(x for x in events if x['event']=='write');fsync=next(x for x in events if x['event']=='fsync-returned')
r={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'hardware_accessed':False,'operator_product_edits':False,'test_type':'Actual collector with a synthetic sink and fsync observation that calls through to the native operation; no power-loss or USB proof','events':events,'fsync_before_write':fsync['monotonic']<=write['monotonic'],'reserved_successor_persisted_before_write':write['state_at_write']['next_sequence']==8 and write['frame_sequence']==7,'frame_sha256':hashlib.sha256((out/'transmitted.bin').read_bytes()).hexdigest()}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
