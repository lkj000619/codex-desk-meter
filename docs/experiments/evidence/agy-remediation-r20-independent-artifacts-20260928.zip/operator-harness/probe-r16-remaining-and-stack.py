import copy,hashlib,json,re,subprocess,sys
from pathlib import Path
e=Path(sys.argv[1]).resolve();out=e/'operator-remaining-contract-tests';assert not out.exists();out.mkdir();root=Path.cwd();c=e/'checkout'
sys.path.insert(0,str(root/'scripts'));import host_device_pipeline as oracle
ref='2026-09-10T16:54:07Z';canonical=json.loads((e/'operator-cli-lifecycle-tests/first-loopback.bin').read_bytes());absolute=json.loads((e/'operator-absolute-value-tests/absolute-token-balance.bin').read_bytes());cases=[]
def add(name,frame):
 frame['sequence']=7;frame['sent_at']=ref
 data=oracle.encode_frame(oracle.build_frame(frame['payload'],7,ref));oracle.decode_frame_line(data);path=out/(name+'.bin');path.write_bytes(data)
 p=subprocess.run([str(e/'operator-scoped-parser-tests/operator-scoped-frame-probe.exe'),str(path),ref],capture_output=True);assert p.returncode==0
 (out/(name+'-stdout.txt')).write_bytes(p.stdout);(out/(name+'-stderr.txt')).write_bytes(p.stderr)
 cases.append({'name':name,'trusted_schema_valid':True,'input_sha256':hashlib.sha256(data).hexdigest(),'actual':json.loads(p.stdout)})
for v in [0,100]:
 f=copy.deepcopy(canonical);w=f['payload']['usage'][0]['windows'][0];w['percent_used']=v;w['percent_remaining']=100-v;add('consistent-percent-'+str(v),f)
for field in ['used_units','remaining_units','limit_units']:
 f=copy.deepcopy(absolute);f['payload']['usage'][0]['windows'][0][field]=None;add('nullable-token-'+field,f)
f=copy.deepcopy(canonical);f['payload']['usage'][0]['windows'][0]['percent_remaining']=None;add('nullable-percent-remaining',f)
f=copy.deepcopy(canonical);w=f['payload']['usage'][0]['windows'][0];w['percent_used']=0;add('schema-valid-independent-percent-fields',f)
text=(e/'operator-scoped-parser-tests/parser-target-disassembly.txt').read_text(encoding='utf-8');functions=[]
for m in re.finditer(r'^([0-9a-f]+) <([^>]+)>:\n(.*?)(?=\n[0-9a-f]+ <|\Z)',text,re.M|re.S):
 name,body=m.group(2),m.group(3);entry=re.search(r'entry\s+a1,\s*(0x[0-9a-fA-F]+|[0-9]+)',body)
 if entry:functions.append({'function':name,'entry_bytes':int(entry.group(1),0),'dynamic_stack_prologue':bool(re.search(r'movsp\s+a1',body[:600]))})
assert functions
argv=[sys.executable,str(c/'scripts/run-host-device-pipeline.py'),'--candidate','--init-device','--force','--recovery-reason','operator_reset_confirmed','--receiver-reset','--device-alias','operator-doc-test','--sequence-store-dir',str(out/'doc-state'),'--sequence','1']
p=subprocess.run(argv,capture_output=True);(out/'documented-recovery-stdout.txt').write_bytes(p.stdout);(out/'documented-recovery-stderr.txt').write_bytes(p.stderr)
run_id=json.loads((e/'evaluation.json').read_text())['run_id'];result_path=c/'results'/run_id/'end-to-end-result.json';submitted=json.loads(result_path.read_text(encoding='utf-8')) if result_path.exists() else {}
def f9_total(value):
 if isinstance(value,dict):
  if 'score_breakdown' in value:return value['score_breakdown'].get('total')
  for child in value.values():
   found=f9_total(child)
   if found is not None:return found
 return None
r={'run_id':run_id,'operator_product_edits':False,'hardware_accessed':False,'cases':cases,'parser_target_functions':functions,'stack_measurement_scope':'Direct function entries only. No dynamic movsp in extracted prologues; library callees, interrupts and runtime margin remain hardware verification. Historical r16 owner CRLF extraction error is preserved separately.','legacy_r16_documented_recovery_command':{'argv':argv,'exit_code':p.returncode,'stderr':p.stderr.decode(errors='replace')},'legacy_r16_documented_periodic_command_default_max_cycles':1,'agent_f9_current_submission_total':f9_total(submitted.get('feature_results',{}).get('F9',{})),'current_result_exists':result_path.exists(),'owner_f9_score':None,'owner_gui_scores':None,'owner_scoring_reason':'Agent self score is not blind owner hardware scoring; full physical implementation completeness remains unverified. Current operational document must be separately inspected; command probe here targets legacy r16 aliases.'}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps({'cases':[{'name':x['name'],'parser':x['actual']['parser_ok'],'accepted':x['actual']['accepted_frames']} for x in cases],'functions':functions,'documented_recovery_exit':p.returncode}))
