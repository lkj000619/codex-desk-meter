import concurrent.futures,json,subprocess,sys,time
from pathlib import Path
e=Path(sys.argv[1]).resolve();b=e.parent;assert b==Path('C:/Espressif/benchmark-remediation');results=[];target=e/'additional-module-commands.json';assert not target.exists()
def run(name,script,args=None):
 argv=[sys.executable,str(b/script),str(e)]+(args or []);start=time.monotonic()
 try:p=subprocess.run(argv,cwd=Path.cwd(),capture_output=True,timeout=120);code=p.returncode;stdout=p.stdout;stderr=p.stderr
 except subprocess.TimeoutExpired as exc:code=124;stdout=exc.stdout or b'';stderr=exc.stderr or b''
 (e/('additional-'+name+'-stdout.txt')).write_bytes(stdout);(e/('additional-'+name+'-stderr.txt')).write_bytes(stderr)
 return {'name':name,'argv':argv,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'stderr_tail':stderr.decode(errors='replace')[-900:]}
def phase(jobs):
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for result in pool.map(lambda x:run(*x),jobs):results.append(result);print(json.dumps(result),flush=True)
 target.write_text(json.dumps({'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'operator_product_edits':False,'hardware_accessed':False,'commands':results,'exit_zero_is_probe_completion_not_product_pass':True},indent=2)+'\n',encoding='utf-8')
phase([('frames','run-independent-frame-probe.py'),('state','run-independent-state-probe.py'),('atomic','run-independent-atomic-probe.py'),('cli','run-independent-cli-lifecycle.py')])
phase([('consistent-clock','probe-r12-consistent-clock.py'),('target-transport-stack','verify-target-stack.py'),('target-state-stack','verify-target-state-stack.py'),('absolute-values','run-independent-absolute-values.py')])
candidate_frame=e/'operator-cli-lifecycle-tests/first-loopback.bin'
if candidate_frame.exists():
 ref=json.loads(candidate_frame.read_bytes())['sent_at']
 phase([('providers','run-independent-provider-probe.py',[str(candidate_frame),ref]),('esp-replay','run-independent-esp-replay-probe.py',[str(candidate_frame),ref]),('envelope-types','run-independent-envelope-types.py')])
phase([('sender-recovery','run-independent-sender-recovery.py'),('active-refresh','run-independent-active-refresh.py'),('durable-reservation','run-independent-durable-reservation.py')])
sys.exit(1 if any(x['exit_code'] for x in results) else 0)
