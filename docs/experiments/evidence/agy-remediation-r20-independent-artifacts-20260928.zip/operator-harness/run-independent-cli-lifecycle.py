import hashlib,json,subprocess,sys,time
from pathlib import Path
e=Path(sys.argv[1]).resolve();c=e/'checkout';root=Path.cwd();out=e/'operator-cli-lifecycle-tests'
assert not out.exists();out.mkdir()
sys.path.insert(0,str(root/'scripts'));import host_device_pipeline as oracle
alias='operator-test-device';store=out/'sequence-store'
base=[sys.executable,str(c/'scripts/run-host-device-pipeline.py'),'--candidate','--device-alias',alias,'--sequence-store-dir',str(store)]
records=[]
def run(name,args,frame_output=False,base_argv=None):
 argv=(base_argv or base)+args
 if frame_output:argv+=['--output',str(out/(name+'.bin'))]
 started=time.monotonic()
 try:
  p=subprocess.run(argv,cwd=c,capture_output=True,timeout=20)
  code=p.returncode;stdout=p.stdout;stderr=p.stderr;timed_out=False
 except subprocess.TimeoutExpired as exc:
  code=None;stdout=exc.stdout or b'';stderr=exc.stderr or b'';timed_out=True
 (out/(name+'-stdout.txt')).write_bytes(stdout);(out/(name+'-stderr.txt')).write_bytes(stderr)
 rec={'name':name,'argv':argv,'exit_code':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-started,'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'stderr_tail':stderr.decode(errors='replace')[-1300:]}
 frame=out/(name+'.bin')
 if frame.exists():
  try:decoded=oracle.decode_frame_line(frame.read_bytes());rec['trusted_frame_sequence']=decoded['sequence'];rec['trusted_usage_count']=len(decoded['payload']['usage']);rec['trusted_frame_valid']=True
  except Exception as exc:rec['trusted_frame_valid']=False;rec['trusted_frame_error']=str(exc)
 records.append(rec);return code
initialized=run('initialize',['--init-device','--sequence','7'])==0
first=run('first-loopback',['--loopback'],True)==0 if initialized else False
if first:
 run('restart-refresh',['--loopback','--refresh'],True)
 run('failed-write',['--mock-fail'],True)
 run('recovery-after-failure',['--loopback'],True)
 run('refuse-existing-initialization',['--init-device','--sequence','1'])
 run('periodic-two-cycles',['--loopback','--max-cycles','2','--poll-interval','1'],True)
 missing=out/'missing-state'
 run('missing-state',['--loopback'],base_argv=base[:-1]+[str(missing)])
summary={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'hardware_accessed':False,'operator_product_edits':False,'independent_test_type':'Actual candidate CLI in fresh processes, fake loopback/failure sink, trusted frame decoding; not hardware proof','commands':records,'source_sha256':hashlib.sha256((c/'scripts/run-host-device-pipeline.py').read_bytes()).hexdigest(),'product_pass':False}
(out/'report.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
