import hashlib,json,subprocess,sys,threading,time
from pathlib import Path
e=Path(sys.argv[1]).resolve();c=e/'checkout';out=e/'operator-active-refresh-tests';assert not out.exists();out.mkdir()
alias='operator-active-refresh';store=out/'state';frame_path=out/'last-frame.bin';base=[sys.executable,str(c/'scripts/run-host-device-pipeline.py'),'--candidate','--device-alias',alias,'--sequence-store-dir',str(store)]
p=subprocess.run(base+['--init-device','--sequence','7'],capture_output=True);assert p.returncode==0
(out/'initialize-stdout.txt').write_bytes(p.stdout);(out/'initialize-stderr.txt').write_bytes(p.stderr)
argv=base+['--loopback','--max-cycles','3','--poll-interval','8','--output',str(frame_path)];stop=threading.Event();events=[]
def monitor():
 previous=None
 while not stop.is_set():
  if frame_path.exists():
   try:data=frame_path.read_bytes();f=json.loads(data)
   except (OSError,json.JSONDecodeError):pass
   else:
    if f['sequence']!=previous:
     previous=f['sequence'];events.append({'sequence':previous,'monotonic':time.monotonic(),'sha256':hashlib.sha256(data).hexdigest()});(out/('sequence-'+str(previous)+'.bin')).write_bytes(data)
  time.sleep(0.025)
t=threading.Thread(target=monitor);t.start();start=time.monotonic()
with (out/'owner-stdout.txt').open('wb') as stdout,(out/'owner-stderr.txt').open('wb') as stderr:
 owner=subprocess.Popen(argv,cwd=c,stdout=stdout,stderr=stderr)
 try:
  while not events and owner.poll() is None and time.monotonic()-start<5:time.sleep(0.025)
  assert events,'owner did not send initial frame'
  time.sleep(0.5);refresh_start=time.monotonic();refresh_argv=base+['--loopback','--refresh']
  refresh=subprocess.run(refresh_argv,cwd=c,capture_output=True,timeout=20);refresh_end=time.monotonic()
  (out/'refresh-stdout.txt').write_bytes(refresh.stdout);(out/'refresh-stderr.txt').write_bytes(refresh.stderr);owner.wait(timeout=20)
 finally:
  if owner.poll() is None:owner.terminate();owner.wait(timeout=10)
  time.sleep(0.1);stop.set();t.join()
r={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'hardware_accessed':False,'operator_product_edits':False,'test_type':'Actual candidate CLI in two processes with file observation, loopback sink; no hardware/ACK proof','owner_argv':argv,'owner_exit_code':owner.returncode,'refresh_argv':refresh_argv,'refresh_exit_code':refresh.returncode,'refresh_command_elapsed_seconds':refresh_end-refresh_start,'observed_frames':events,'refresh_invoked_at':refresh_start,'first_frame_after_refresh_seconds':next((x['monotonic']-refresh_start for x in events if x['monotonic']>=refresh_start),None),'configured_poll_interval_seconds':8,'first_to_third_observed_seconds':events[2]['monotonic']-events[0]['monotonic'] if len(events)>=3 else None}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
