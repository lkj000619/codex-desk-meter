import hashlib,json,subprocess,sys,time
from pathlib import Path
e=Path('C:/Espressif/benchmark-remediation/evaluation-r11-20260928');c=e/'checkout';out=e/'operator-cli-tests'
assert not out.exists();out.mkdir()
common=[sys.executable,str(c/'scripts/run-host-device-pipeline.py'),'--candidate','--device-alias','operator-test-device','--sequence-store-dir',str(out/'sequence-store')]
results=[]
for name,args in [('initialize',['--init-device','--sequence','7']),('loopback-send',['--loopback'])]:
 start=time.monotonic()
 try:
  p=subprocess.run(common+args,cwd=c,capture_output=True,timeout=25)
  stdout=p.stdout;stderr=p.stderr;code=p.returncode;timeout=False
 except subprocess.TimeoutExpired as exc:
  stdout=exc.stdout or b'';stderr=exc.stderr or b'';code=None;timeout=True
 (out/(name+'-stdout.txt')).write_bytes(stdout);(out/(name+'-stderr.txt')).write_bytes(stderr)
 results.append({'name':name,'argv':common+args,'exit_code':code,'timeout':timeout,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_sha256':hashlib.sha256(stderr).hexdigest(),'stderr_tail':stderr.decode(errors='replace')[-1200:]})
report={'run_id':'20260928-agy-remediation-r11','hardware_accessed':False,'operator_product_edits':False,'commands':results,'product_pass':False}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
