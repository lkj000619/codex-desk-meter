import hashlib,json,os,re,subprocess,sys
from pathlib import Path
e=Path(sys.argv[1]).resolve();c=e/'checkout';out=e/'operator-scoped-parser-tests';assert not (out/'report.json').exists();out.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=e.parent/'operator-frame-probe.c';text=original.read_text(encoding='utf-8')
text=text.replace('int ok = meter_parse_cdm_frame(bytes, parser_len, frame, error, sizeof(error));','char saved = bytes[parser_len]; bytes[parser_len] = 0;\n    int ok = meter_parse_cdm_frame(bytes, parser_len, frame, error, sizeof(error));\n    bytes[parser_len] = saved;')
src=out/'operator-scoped-frame-probe.c';src.write_text(text,encoding='utf-8');exe=out/'operator-scoped-frame-probe.exe'
p=subprocess.run([os.environ.get('CC','cc'),'-I',str(c/'components/meter/include'),str(src),str(c/'build-host/libmeter_core.a'),'-o',str(exe)],capture_output=True)
(out/'compile-stdout.txt').write_bytes(p.stdout);(out/'compile-stderr.txt').write_bytes(p.stderr);assert p.returncode==0
cases=[]
for folder in ['operator-consistent-clock-tests','operator-absolute-value-tests']:
 report=json.loads((e/folder/'report.json').read_text());ref=report['reference_time']
 for old in report['cases']:
  path=e/folder/(old['name']+'.bin');assert path.exists()
  p=subprocess.run([str(exe),str(path),ref],capture_output=True);assert p.returncode==0
  (out/(old['name']+'-stdout.txt')).write_bytes(p.stdout);(out/(old['name']+'-stderr.txt')).write_bytes(p.stderr)
  cases.append({'group':folder,'name':old['name'],'input_sha256':h(path),'trusted':old.get('trusted_line',{'accepted':old.get('trusted_frame_valid')}),'original_actual':old['actual'],'scoped_actual':json.loads(p.stdout)})
cache=(c/'build/CMakeCache.txt').read_text(encoding='utf-8');dump=re.search(r'^CMAKE_OBJDUMP:FILEPATH=(.+)$',cache,re.M).group(1).strip()
obj=c/'build/esp-idf/meter/CMakeFiles/__idf_meter.dir/meter_parser.c.obj';p=subprocess.run([dump,'-dr',str(obj)],capture_output=True);assert p.returncode==0
(out/'parser-target-disassembly.txt').write_bytes(p.stdout);functions=[]
for match in re.finditer(r'^([0-9a-f]+) <([^>]+)>:\n(.*?)(?=\n[0-9a-f]+ <|\Z)',p.stdout.decode().replace('\r\n','\n'),re.M|re.S):
 name,body=match.group(2),match.group(3);entry=re.search(r'entry\s+a1,\s*(0x[0-9a-fA-F]+|[0-9]+)',body)
 if entry:functions.append({'function':name,'entry_bytes':int(entry.group(1),0),'dynamic_stack_prologue':bool(re.search(r'movsp\s+a1',body[:600])),'prologue':body[:350]})
r={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'operator_product_edits':False,'hardware_accessed':False,'owner_tool_history':'r16 initial CC assumption and CRLF regex extraction errors preserved in original reports; helper uses existing cc and normalized disassembly newline on subsequent runs. Historical owner errors, not a new candidate failure.','owner_harness_adjustment':'Direct parser receives NUL exactly at its length, matching actual transport. Original direct-buffer reports retained; transport bytes/observations unchanged. This does not prove arbitrary length-bounded parser inputs.','original_owner_probe_sha256':h(original),'scoped_owner_probe_sha256':h(src),'cases':cases,'target_parser_functions':functions,'stack_scope':'Function entry measurements, not full runtime stack bound','object_sha256':h(obj)}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'cases':[{'name':x['name'],'trusted':x['trusted']['accepted'],'parser':x['scoped_actual']['parser_ok'],'accepted':x['scoped_actual']['accepted_frames'],'parsed':x['scoped_actual']['parsed_usage'] if x['group'].endswith('absolute-value-tests') else None} for x in cases],'stack':[{k:v for k,v in f.items() if k!='prologue'} for f in functions]}))
