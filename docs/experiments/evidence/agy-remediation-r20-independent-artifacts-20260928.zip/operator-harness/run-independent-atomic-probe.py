import copy,hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd();e=Path(sys.argv[1]).resolve();c=e/'checkout';out=e/'operator-atomic-state-tests';assert not out.exists();out.mkdir()
sys.path.insert(0,str(root/'scripts'));import host_device_pipeline as oracle
ref='2026-09-10T16:54:07Z';payload=oracle.FixtureRegistry.with_defaults(root,reference_time=ref).collect().payload
payload['usage']=payload['usage'][:1]
initial=oracle.encode_frame(oracle.build_frame(payload,1,ref));changed=copy.deepcopy(payload)
changed['usage'][0]['windows'][0].update(percent_used=40,percent_remaining=60)
for reset in changed['global_resets']:reset['captured_at']='2026-09-10T17:00:00Z'
later=oracle.encode_frame(oracle.build_frame(changed,2,ref))
paths=[]
for name,data in [('initial',initial),('future-global-after-provider-update',later)]:
 p=out/(name+'.bin');p.write_bytes(data);paths.append(p)
src=e.parent/'operator-atomic-state-probe.c';exe=out/'probe.exe'
p=subprocess.run([os.environ.get('CC','cc'),'-I',str(c/'components/meter/include'),str(src),str(c/'build-host/libmeter_core.a'),'-o',str(exe)],capture_output=True)
(out/'compile-stdout.txt').write_bytes(p.stdout);(out/'compile-stderr.txt').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode(errors='replace')
p=subprocess.run([str(exe),*[str(x) for x in paths],ref],capture_output=True);assert p.returncode==0
(out/'probe-stdout.txt').write_bytes(p.stdout);(out/'probe-stderr.txt').write_bytes(p.stderr)
report={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'hardware_accessed':False,'operator_product_edits':False,'actual':json.loads(p.stdout),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'input_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'assertion_policy':'If the entire second frame is rejected, last-good/provider/ordering data must not change. Alternatively a schema-valid frame may be accepted with a provider-local/global source error and last-good preservation, according to the existing contract.'}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
