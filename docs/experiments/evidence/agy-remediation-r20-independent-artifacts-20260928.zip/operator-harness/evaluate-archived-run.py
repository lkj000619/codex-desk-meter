import datetime,hashlib,io,json,subprocess,sys,time,zipfile,os
from pathlib import Path
r=Path(sys.argv[1]).resolve();root=Path.cwd();read=lambda p:json.loads(p.read_text(encoding='utf-8'));h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=read(r/'archive-record.json');assert record['status'] not in ['running','prepared'];assert record['inputs_immutable'] and record['globals_restored']
assert not (r.with_name(r.name+'-agy-config')/'active.json').exists()
e=r.parent/('evaluation-'+r.name.rsplit('-',1)[1]+'-20260928');c=e/'checkout';resume='--resume' in sys.argv[2:]
assert e.exists()==resume
if not resume:c.mkdir(parents=True)
z=zipfile.ZipFile(io.BytesIO(subprocess.check_output(['git','archive','--format=zip',record['implementation_commit']],cwd=r/'checkout')))
for entry in z.infolist():assert (c/entry.filename).resolve().is_relative_to(c)
if not resume:z.extractall(c)
source={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}
assert all(h(c/n)==sha for n,sha in source.items())
manifest=read(e/'evaluation.json') if resume else {'run_id':r.name,'implementation_commit':record['implementation_commit'],'operator_product_code_edits':False,'fresh_git_archive':True,'source_file_hashes':source,'commands':[],'product_pass':False,'hardware_verified':False,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
if resume:
    assert manifest['implementation_commit']==record['implementation_commit']
    manifest.setdefault('operator_launch_errors',[]).append({'name':'idf-set-target','error':'WinError 193 launching idf.py directly on Windows; corrected to pinned Python plus SDK idf.py path','candidate_failure':False})
def save():(e/'evaluation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
def run(name,argv):
    previous=next((x for x in manifest['commands'] if x['name']==name),None)
    if previous and previous['exit_code']==0:return 0
    started=time.monotonic();timed_out=False
    try:p=subprocess.run(argv,cwd=c,capture_output=True,timeout=180 if name=='candidate-python-tests' else 600)
    except subprocess.TimeoutExpired as exc:
        timed_out=True;p=subprocess.CompletedProcess(argv,124,exc.stdout or b'',exc.stderr or b'')
    (e/(name+'-stdout.txt')).write_bytes(p.stdout);(e/(name+'-stderr.txt')).write_bytes(p.stderr)
    result={'name':name,'argv':argv,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-started,'timed_out':timed_out,'stdout_sha256':h(e/(name+'-stdout.txt')),'stderr_sha256':h(e/(name+'-stderr.txt'))}
    manifest['commands'].append(result);save();print(json.dumps(result),flush=True)
    return p.returncode
save()
for name,argv in [('host-configure',['cmake','-S','.','-B','build-host','-G','Ninja']),('host-build',['cmake','--build','build-host'])]:
    if run(name,argv):sys.exit(1)
run('ctest',['ctest','--test-dir','build-host','--output-on-failure'])
run('candidate-python-tests',[sys.executable,'-m','unittest','discover','-s','tests','-v'])
run('legacy-29',[sys.executable,'tests/test_evaluation_adapter.py'])
idf=[sys.executable,str(Path(os.environ['IDF_PATH'])/'tools/idf.py')]
if run('idf-set-target',idf+['set-target','esp32s3'])==0:run('idf-build',idf+['build'])
result_path=c/'results'/r.name/'end-to-end-result.json'
if result_path.exists():
    run('trusted-result-validation',[sys.executable,str(root/'scripts/validate-end-to-end-result.py'),'--result',str(result_path),'--manifest',str(r/'e2e-evaluation-manifest.json'),'--evidence-root',str(c)])
else:manifest['structured_result_missing']=True
manifest['source_changes_after_build']={n:{'original_sha256':sha,'current_sha256':h(c/n) if (c/n).exists() else None} for n,sha in source.items() if not (c/n).exists() or h(c/n)!=sha}
manifest['binary_hashes']={n:h(c/'build'/n) for n in ['codex-desk-meter.bin','codex-desk-meter.elf','bootloader/bootloader.bin','partition_table/partition-table.bin'] if (c/'build'/n).exists()}
manifest['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({'evaluation':str(e),'nonzero_commands':[x['name'] for x in manifest['commands'] if x['exit_code']],'product_pass':False}),flush=True)
sys.exit(1 if any(x['exit_code'] for x in manifest['commands']) or manifest.get('structured_result_missing') or manifest.get('source_changes_after_build') else 0)
