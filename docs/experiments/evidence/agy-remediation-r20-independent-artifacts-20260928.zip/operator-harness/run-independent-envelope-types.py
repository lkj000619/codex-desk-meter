import copy,hashlib,json,subprocess,sys,zlib
from pathlib import Path
root=Path.cwd();e=Path(sys.argv[1]).resolve();out=e/'operator-envelope-type-tests';assert not out.exists();out.mkdir()
sys.path.insert(0,str(root/'scripts'));import host_device_pipeline as oracle
base=json.loads((e/'operator-cli-lifecycle-tests/first-loopback.bin').read_bytes());ref=base['sent_at'];cases=[]
for name,path,value in [('fractional-sequence',('sequence',),7.5),('overflow-sequence',('sequence',),4294967296),('boolean-sequence',('sequence',),True),('invalid-integrity-algorithm',('integrity','algorithm'),'sha256'),('extra-integrity-key',('integrity','unexpected'),True),('extra-payload-key',('payload','unexpected'),True)]:
 f=copy.deepcopy(base);target=f
 for key in path[:-1]:target=target[key]
 target[path[-1]]=value;body={k:v for k,v in f.items() if k!='integrity'}
 f['integrity']['value']=f'{zlib.crc32(json.dumps(body,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode())&0xffffffff:08X}'
 data=(json.dumps(f,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode();p=out/(name+'.bin');p.write_bytes(data)
 try:oracle.decode_frame_line(data);trusted=True;error=None
 except Exception as exc:trusted=False;error=str(exc)
 actual=subprocess.run([str(e/'operator-frame-tests/operator-frame-probe.exe'),str(p),ref],capture_output=True);assert actual.returncode==0
 (out/(name+'-stdout.txt')).write_bytes(actual.stdout);(out/(name+'-stderr.txt')).write_bytes(actual.stderr)
 cases.append({'name':name,'trusted_accepted':trusted,'trusted_error':error,'actual':json.loads(actual.stdout),'input_sha256':hashlib.sha256(data).hexdigest()})
r={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'hardware_accessed':False,'operator_product_edits':False,'reference_time':ref,'cases':cases}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
