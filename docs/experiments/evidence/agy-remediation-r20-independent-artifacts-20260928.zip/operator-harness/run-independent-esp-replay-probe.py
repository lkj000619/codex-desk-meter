import hashlib,json,os,subprocess,sys
from pathlib import Path
e=Path(sys.argv[1]).resolve();c=e/'checkout';out=e/'operator-esp-replay-tests'
assert e.parent==Path('C:/Espressif/benchmark-remediation') and not out.exists()
out.mkdir();stubs=out/'stubs'
headers={
 'freertos/FreeRTOS.h':'''#pragma once
#include <stdint.h>
#include <stddef.h>
typedef int esp_err_t;
#define ESP_OK 0
#define pdMS_TO_TICKS(x) (x)
static inline const char *esp_err_to_name(int x){return "stub";}
''',
 'freertos/task.h':'''#pragma once
#include "FreeRTOS.h"
static inline void vTaskDelete(void *p){}
static inline int xTaskCreate(void (*f)(void*),const char*n,unsigned s,void*a,int p,void*h){return 1;}
''',
 'driver/uart.h':'''#pragma once
#include "freertos/FreeRTOS.h"
#define UART_NUM_0 0
#define UART_DATA_8_BITS 8
#define UART_PARITY_DISABLE 0
#define UART_STOP_BITS_1 1
#define UART_HW_FLOWCTRL_DISABLE 0
#define UART_SCLK_DEFAULT 0
typedef struct{int baud_rate,data_bits,parity,stop_bits,flow_ctrl,source_clk;}uart_config_t;
static inline int uart_read_bytes(int p,void*b,size_t n,int t){return 0;}
static inline int uart_param_config(int p,const uart_config_t*c){return 0;}
static inline int uart_driver_install(int p,int r,int t,int q,void*h,int f){return 0;}
''',
 'driver/usb_serial_jtag.h':'''#pragma once
#include "freertos/FreeRTOS.h"
typedef struct{int tx_buffer_size,rx_buffer_size;}usb_serial_jtag_driver_config_t;
static inline int usb_serial_jtag_read_bytes(void*b,size_t n,int t){return 0;}
static inline int usb_serial_jtag_driver_install(const usb_serial_jtag_driver_config_t*c){return 0;}
''',
 'esp_timer.h':'''#pragma once
#include <stdint.h>
extern int64_t operator_clock_us;
static inline int64_t esp_timer_get_time(void){return operator_clock_us;}
''',
 'esp_log.h':'''#pragma once
#include <stdio.h>
#define ESP_LOGI(tag,fmt,...) fprintf(stderr,fmt "\\n",##__VA_ARGS__)
#define ESP_LOGW(tag,fmt,...) fprintf(stderr,fmt "\\n",##__VA_ARGS__)
''',
}
for name,s in headers.items():
 p=stubs/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
source='''#include <stdio.h>
#include <stdlib.h>
#include "meter_transport.h"
int64_t operator_clock_us;
int main(int argc,char**argv){
 if(argc!=3)return 2;
 FILE*f=fopen(argv[1],"rb");if(!f)return 3;
 fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);
 unsigned char*b=malloc(n);fread(b,1,n,f);fclose(f);
 meter_state_t*s=calloc(1,sizeof(*s));meter_transport_t t;
 meter_state_init(s);meter_transport_init(&t,s);
 operator_clock_us=10000000;meter_transport_process_bytes(&t,b,n,argv[2]);
 long long first=s->last_update_mono_sec;
 operator_clock_us=999000000;meter_transport_process_bytes(&t,b,n,argv[2]);
 printf("{\\"accepted\\":%u,\\"rejected\\":%u,\\"first_receive_mono\\":%lld,\\"after_duplicate_receive_mono\\":%lld}\\n",(unsigned)s->accepted_frames,(unsigned)s->rejected_frames,first,(long long)s->last_update_mono_sec);
 free(b);return 0;
}
'''
src=out/'probe.c';src.write_text(source)
exe=out/'probe.exe'
argv=[os.environ.get('CC','cc'),'-DESP_PLATFORM','-I',str(stubs),'-I',str(c/'components/meter/include'),str(src),str(c/'components/meter/meter_transport.c'),str(c/'build-host/libmeter_core.a'),'-o',str(exe)]
p=subprocess.run(argv,capture_output=True)
(out/'compile-stdout.txt').write_bytes(p.stdout);(out/'compile-stderr.txt').write_bytes(p.stderr)
assert p.returncode==0,p.stderr.decode(errors='replace')
input_path=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else e/'operator-frame-tests/canonical.bin'
reference_time=sys.argv[3] if len(sys.argv)>3 else '2026-09-10T00:04:59Z'
p=subprocess.run([str(exe),str(input_path),reference_time],capture_output=True)
(out/'probe-stdout.txt').write_bytes(p.stdout);(out/'probe-stderr.txt').write_bytes(p.stderr)
assert p.returncode==0
report={'implementation_commit':json.loads((e/'evaluation.json').read_text())['implementation_commit'],'hardware_accessed':False,'reference_time':reference_time,'input_path':str(input_path),'test_type':'Actual ESP conditional transport source with timer/driver test doubles; not hardware proof','operator_product_edits':False,'actual':json.loads(p.stdout),'logs':p.stderr.decode(errors='replace'),'production_transport_sha256':hashlib.sha256((c/'components/meter/meter_transport.c').read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(input_path.read_bytes()).hexdigest(),'compile_argv':argv}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
