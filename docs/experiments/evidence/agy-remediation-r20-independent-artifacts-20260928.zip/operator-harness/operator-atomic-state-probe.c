#include <stdio.h>
#include <stdlib.h>
#include "meter_transport.h"
static void feed(meter_transport_t*t,const char*path,const char*ref){
 FILE*f=fopen(path,"rb");if(!f)exit(2);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);
 unsigned char*b=malloc(n);fread(b,1,n,f);fclose(f);meter_transport_process_bytes(t,b,n,ref);free(b);
}
int main(int argc,char**argv){
 if(argc!=4)return 1;
 meter_state_t*s=calloc(1,sizeof(*s));meter_transport_t t;meter_state_init(s);meter_transport_init(&t,s);
 feed(&t,argv[1],argv[3]);double before=s->last_good_usage.windows[0].percent_used;unsigned seq=s->current_sequence;
 feed(&t,argv[2],argv[3]);
 printf("{\"before_good_percent_used\":%.17g,\"after_good_percent_used\":%.17g,\"sequence_before\":%u,\"sequence_after\":%u,\"accepted\":%u,\"rejected\":%u,\"active_global_error\":\"%s\",\"last_good_reset_fetched_at\":\"%s\"}\n",before,s->last_good_usage.windows[0].percent_used,seq,(unsigned)s->current_sequence,(unsigned)s->accepted_frames,(unsigned)s->rejected_frames,s->active_reset.error_code,s->last_good_reset.fetched_at);
 meter_transport_deinit(&t);free(s);return 0;
}
