import hashlib, importlib.util, json, sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

e=Path('C:/Espressif/benchmark-remediation/evaluation-r10-20260928')
c=e/'checkout'; out=e/'operator-state-tests'
assert not (out/'report.json').exists()
spec=importlib.util.spec_from_file_location('candidate_pipeline',c/'scripts/host_device_pipeline.py')
candidate=importlib.util.module_from_spec(spec);sys.modules[spec.name]=candidate;spec.loader.exec_module(candidate)
alias='operator-test-device';state_dir=out/'sequence-store-r02'
assert not state_dir.exists()
store=candidate.PersistentSequenceStore(state_dir);store.initialize_device(alias,7)
def reserve(i):
    try:return {'request':i,'sequence':candidate.PersistentSequenceStore(state_dir).reserve_next_sequence(alias)}
    except Exception as exc:return {'request':i,'error_type':type(exc).__name__,'error':str(exc)}
with ThreadPoolExecutor(max_workers=8) as pool:
    outcomes=list(pool.map(reserve,range(32)))
values=[x['sequence'] for x in outcomes if 'sequence' in x]
before=store.get_current_sequence(alias);store.initialize_device(alias,1);after=store.get_current_sequence(alias)
report={
 'run_id':'20260928-agy-remediation-r10',
 'implementation_commit':json.loads((e/'evaluation.json').read_text())['implementation_commit'],
 'operator_test_harness_only':True,'hardware_accessed':False,
 'c_state_cases':[json.loads(line) for line in (out/'probe-stdout.txt').read_text().splitlines()],
 'initial_concurrency_probe':{'completed':False,'observed_exception':'PipelineError: SEQUENCE_STORE_WRITE_FAILED: [WinError 5] Access is denied during concurrent temporary-file replacement','state_directory_preserved':str(out/'sequence-store')},
 'sequence_reservation_outcomes':outcomes,'successful_reservations':len(values),
 'unique_reservation_count':len(set(values)),'duplicate_reservation_count':len(values)-len(set(values)),
 'error_count':len(outcomes)-len(values),'requested_reservation_count':32,
 'sequence_before_reinitialize':before,'sequence_after_reinitialize':after,
 'input_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.bin')},
 'candidate_module_sha256':hashlib.sha256((c/'scripts/host_device_pipeline.py').read_bytes()).hexdigest(),
 'source_sha256':hashlib.sha256((e.parent/'operator-state-probe.c').read_bytes()).hexdigest(),
 'product_pass':False,
}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
