import contextlib,datetime,hashlib,importlib.util,io,json,sys,time
from pathlib import Path
b=Path('C:/Espressif/benchmark-remediation');e=b/'evaluation-r16-20260928';c=e/'checkout';hw=b/'hardware-r16-20260929';out=hw/'instrumented-sender-observation';assert not out.exists();out.mkdir();store=hw/'actual-cli-tests/sequence-store';alias='esp32s3-288485b08518'
sys.path.insert(0,str(c/'scripts'));import host_device_pipeline as candidate
spec=importlib.util.spec_from_file_location('candidate_cli',c/'scripts/run-host-device-pipeline.py');cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
original=candidate.open_owner_serial;events=[];records=[];current=[None]
class Observed:
 def __init__(self,s):self.s=s;self.data=bytearray();self.error=None
 def write(self,data):
  events.append({'event':'actual_backend_write','case':current[0],'monotonic':time.monotonic(),'sequence':json.loads(data)['sequence'],'frame_sha256':hashlib.sha256(data).hexdigest()});return self.s.write(data)
 def flush(self):return self.s.flush()
 def close(self):
  begin=time.monotonic()
  try:
   while time.monotonic()-begin<3:self.data.extend(self.s.read(4096))
  except Exception as exc:self.error=repr(exc)
  finally:self.s.close()
  path=out/(current[0]+'-device-log.txt');path.write_text(self.data.decode('utf-8',errors='replace'),encoding='utf-8');events.append({'event':'read_existing_firmware_logs_before_close','case':current[0],'elapsed_seconds':time.monotonic()-begin,'errors':self.error,'log_path':path.name,'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
def factory(port):
 s=original(port);events.append({'event':'original_candidate_backend_open','case':current[0],'port':port,'dtr':s.dtr,'rts':s.rts});return Observed(s)
candidate.open_owner_serial=factory
for name,extra in [('ordinary-process-restart',[]),('manual-refresh',['--refresh'])]:
 current[0]=name;stdout=io.StringIO();stderr=io.StringIO();args=['--candidate','--device-alias',alias,'--sequence-store-dir',str(store),'--send','--port','COM3','--max-cycles','1','--output',str(out/(name+'-frame.bin'))]+extra;start=time.monotonic()
 with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):code=cli.main(args)
 for kind,value in [('stdout',stdout.getvalue()),('stderr',stderr.getvalue())]:(out/(name+'-'+kind+'.txt')).write_text(value,encoding='utf-8')
 records.append({'name':name,'actual_candidate_cli_argv':args,'exit_code':code,'elapsed_seconds_includes_operator_read_delay':time.monotonic()-start,'next_sequence':candidate.PersistentSequenceStore(store).get_current_sequence(alias)})
 if code:break
candidate.open_owner_serial=original
r={'run_id':'20260928-agy-remediation-r16','implementation_commit':json.loads((e/'evaluation.json').read_text())['implementation_commit'],'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operator_product_edits':False,'ranking_eligible':False,'product_pass':False,'hardware_accessed':True,'instrumentation':'Actual candidate CLI main and original real serial backend. Owner proxy delegates native write/flush/open unchanged and reads existing firmware logs for3s before original close. No ACK protocol/product edits/reset/counter init. Instrumented elapsed times are excluded from candidate latency/performance/quantitative cohort. Raw prior actual CLI seq7 report retained.','records':records,'events':events}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
