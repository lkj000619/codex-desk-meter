import datetime,hashlib,json,sys,time
from pathlib import Path
b=Path('C:/Espressif/benchmark-remediation');e=b/'evaluation-r16-20260928';c=e/'checkout';hw=b/'hardware-r16-20260929';out=hw/'powered-ordering-test';assert not out.exists();out.mkdir();sys.path.insert(0,str(c/'scripts'));import host_device_pipeline as candidate
store=candidate.PersistentSequenceStore(hw/'actual-cli-tests/sequence-store');alias='esp32s3-288485b08518';records=[];ref='2026-09-10T16:54:07Z';payload=candidate.FixtureRegistry.with_defaults(c,reference_time=ref).collect().payload
def read(s,name):
 data=bytearray();start=time.monotonic();errors=[]
 try:
  while time.monotonic()-start<3:data.extend(s.read(4096))
 except Exception as exc:errors.append(repr(exc))
 text=data.decode(errors='replace');path=out/(name+'-device-log.txt');path.write_text(text,encoding='utf-8');records.append({'name':name,'type':'existing_log_observation','errors':errors,'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'text':text});return text
def write(s,name,seq,reserved):
 data=candidate.encode_frame(candidate.build_frame(payload,seq,ref));path=out/(name+'.bin');path.write_bytes(data);written=s.write(data);s.flush();records.append({'name':name,'type':'owner_protocol_conformance_injection','sequence':seq,'reserved_with_actual_candidate_store':reserved,'bytes_written':written,'frame_sha256':hashlib.sha256(data).hexdigest()});return read(s,name)
with store.owner_lock(alias):
 s=candidate.open_owner_serial('COM3');read(s,'first-native-backend-open')
 try:
  high=store.reserve_next_sequence(alias);write(s,'persisted-current-sequence',high,True);write(s,'low1-same-open-backend',1,False)
 finally:s.close()
 time.sleep(1)
 s=candidate.open_owner_serial('COM3');read(s,'reopened-original-native-backend')
 try:
  write(s,'low1-after-native-backend-reopen',1,False);high=store.reserve_next_sequence(alias);write(s,'persisted-successor',high,True)
 finally:s.close()
r={'run_id':'20260928-agy-remediation-r16','implementation_commit':json.loads((e/'evaluation.json').read_text())['implementation_commit'],'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operator_product_edits':False,'ranking_eligible':False,'product_pass':False,'hardware_accessed':True,'scope':'Owner protocol conformance injection using actual candidate fixture collection/frame encoder/store and ORIGINAL real serial backend. Not actual automatic CLI/performance evidence. Candidate store numbers consumed durably; low1 is intentional invalid-order test, never ordinary sender recovery. Board remains USB-powered; no explicit reset/erase/init requested. Open/close behavior is subject under test.','next_sequence':store.get_current_sequence(alias),'records':records}
(out/'report.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
