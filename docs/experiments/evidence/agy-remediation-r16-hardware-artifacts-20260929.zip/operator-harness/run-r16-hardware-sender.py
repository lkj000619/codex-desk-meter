import datetime,hashlib,json,subprocess,sys,time
from pathlib import Path
import serial
from serial.tools import list_ports
b=Path('C:/Espressif/benchmark-remediation');e=b/'evaluation-r16-20260928';c=e/'checkout';hw=b/'hardware-r16-20260929';out=hw/'actual-cli-tests';assert not out.exists();out.mkdir();alias='esp32s3-288485b08518';store=out/'sequence-store'
assert any(p.device=='COM3' and p.vid==0x303A and p.pid==0x1001 and p.serial_number.upper()=='28:84:85:B0:85:18' for p in list_ports.comports())
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();records=[]
def save():
 (out/'report.json').write_text(json.dumps({'run_id':'20260928-agy-remediation-r16','implementation_commit':json.loads((e/'evaluation.json').read_text())['implementation_commit'],'ranking_eligible':False,'operator_product_edits':False,'hardware_accessed':True,'product_pass':False,'board_identity':'303A:1001 /28:84:85:B0:85:18','stable_device_alias':alias,'receiver_reset':'Only reset was recorded initial post-flash reset before explicit store creation; ordinary process restarts below request no reset','commands':records},indent=2)+'\n',encoding='utf-8')
def run(name,args):
 argv=[sys.executable,str(c/'scripts/run-host-device-pipeline.py'),'--candidate','--device-alias',alias,'--sequence-store-dir',str(store)]+args;start=time.monotonic();p=subprocess.run(argv,cwd=c,capture_output=True,timeout=25)
 for k,v in [('stdout',p.stdout),('stderr',p.stderr)]:(out/(name+'-'+k+'.txt')).write_bytes(v)
 rec={'name':name,'argv':argv,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'completed_at':now(),'stdout_sha256':h(out/(name+'-stdout.txt')),'stderr_sha256':h(out/(name+'-stderr.txt'))};records.append(rec);save();print(json.dumps(rec),flush=True);assert p.returncode==0
def capture(name,seconds=4):
 s=serial.Serial(port=None,baudrate=115200,timeout=.1,rtscts=False,dsrdtr=False);s.dtr=False;s.rts=False;s.port='COM3';data=bytearray();s.open();start=time.monotonic()
 try:
  while time.monotonic()-start<seconds:data.extend(s.read(4096))
 finally:s.close()
 path=out/(name+'-device-log.txt');text=data.decode('utf-8',errors='replace');path.write_text(text,encoding='utf-8');rec={'name':name,'operator_observation':'Post-send serial read with DTR/RTS false; no reset requested; separate COM owner after actual CLI exit','capture_seconds':seconds,'log_sha256':h(path),'accepted_sequences':re_find(text),'boot_marker_present':'Starting Codex Desk Meter' in text,'panic_marker_present':'Guru Meditation' in text or 'stack overflow' in text};records.append(rec);save();print(json.dumps(rec),flush=True)
def re_find(text):
 import re
 return [int(x) for x in re.findall(r'Accepted cdm/1 frame seq=(\d+)',text)]
run('explicit-init',['--init-device','--sequence','7'])
run('first-actual-send',['--send','--port','COM3','--max-cycles','1','--output',str(out/'first-actual-frame.bin')]);capture('after-first-send')
run('ordinary-process-restart',['--send','--port','COM3','--max-cycles','1','--output',str(out/'restart-actual-frame.bin')]);capture('after-process-restart')
run('manual-refresh',['--refresh','--send','--port','COM3','--max-cycles','1','--output',str(out/'refresh-actual-frame.bin')]);capture('after-manual-refresh')
save()
