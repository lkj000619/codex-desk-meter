import datetime,hashlib,json,sys,time
from pathlib import Path
import serial
out=Path('C:/Espressif/benchmark-remediation/hardware-r16-20260929');name=sys.argv[1];base=out/name;assert not base.with_suffix('.json').exists();data=bytearray();errors=[];start=time.monotonic()
try:
 s=serial.Serial('COM3',115200,timeout=.1)
 try:
  while time.monotonic()-start<8:
   try:data.extend(s.read(4096))
   except Exception as exc:errors.append(repr(exc));break
 finally:s.close()
except Exception as exc:errors.append(repr(exc))
text=data.decode('utf-8',errors='replace');base.with_suffix('.txt').write_text(text,encoding='utf-8');r={'operator_product_edits':False,'ranking_eligible':False,'product_pass':False,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'observation':'Separate serial reader uses same default control lines as candidate backend; no explicit reset requested; opening serial may itself alter device control lines, so ordering acceptance is unverified until logs prove it','errors':errors,'text':text,'sha256':hashlib.sha256(base.with_suffix('.txt').read_bytes()).hexdigest()};base.with_suffix('.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
