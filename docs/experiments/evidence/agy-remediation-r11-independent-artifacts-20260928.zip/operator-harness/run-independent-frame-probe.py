import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd();e=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('C:/Espressif/benchmark-remediation/evaluation-r10-20260928');c=e/'checkout';out=e/'operator-frame-tests';assert not out.exists();out.mkdir()
sys.path.insert(0,str(root/'scripts'));import host_device_pipeline as oracle
compiler=os.environ.get('CC','cc');exe=out/'operator-frame-probe.exe';src=e.parent/'operator-frame-probe.c'
p=subprocess.run([compiler,'-I',str(c/'components/meter/include'),str(src),str(c/'build-host/libmeter_core.a'),'-o',str(exe)],capture_output=True)
(out/'compile-stdout.txt').write_bytes(p.stdout);(out/'compile-stderr.txt').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode(errors='replace')
ref='2026-09-10T00:04:59Z';registry=oracle.FixtureRegistry.with_defaults(root,reference_time=ref)
payload=registry.collect().payload;frame=oracle.build_frame(payload,sequence=7,sent_at=ref);line=oracle.encode_frame(frame)
variants={'canonical':line,'crlf':line[:-1]+b'\r\n','pretty_json':(json.dumps(frame,indent=2)+'\n').encode(),'extra_newline':line+b'\n','overlong_prefix_then_valid':b'x'*65536+line,'overlong_then_delimiter_then_valid':b'x'*65536+b'\n'+line,'junk_prefix':b'junk'+line,'junk_suffix':line[:-1]+b'junk\n','invalid_utf8':line.replace(b'openai',b'open\xffai',1),'crc_mismatch':line.replace(frame['integrity']['value'].encode(),b'00000000',1),'truncated':line[:-10]+b'\n'}
results=[]
for name,data in variants.items():
    path=out/(name+'.bin');path.write_bytes(data)
    p=subprocess.run([str(exe),str(path),ref],capture_output=True)
    (out/(name+'-stdout.txt')).write_bytes(p.stdout);(out/(name+'-stderr.txt')).write_bytes(p.stderr)
    decoded=json.loads(p.stdout) if p.returncode==0 else {'probe_exit_code':p.returncode}
    results.append({'name':name,'input_sha256':hashlib.sha256(data).hexdigest(),'reference_valid_frame':name=='canonical','actual':decoded})
report={'run_id':json.loads((e/'evaluation.json').read_text())['run_id'],'implementation_commit':json.loads((e/'evaluation.json').read_text())['implementation_commit'],'operator_test_harness_only':True,'hardware_accessed':False,'canonical_expected_provider_count':len(payload['usage']),'cases':results,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'product_pass':False}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
