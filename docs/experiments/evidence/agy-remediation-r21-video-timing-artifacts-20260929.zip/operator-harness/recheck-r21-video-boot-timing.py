import hashlib
import json
import re
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw

base = Path('C:/Espressif/benchmark-remediation')
source = base / 'hardware-r21-20260929/user-media-01/video.mp4'
out = base / 'hardware-r21-20260929/video-timing-recheck-20260929'
out.mkdir(exist_ok=True)
ffmpeg = Path('C:/Espressif/tmp/codex-video-tools/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe')
windows = [(186, 222), (360, 396), (603, 639)]
records = []
for window_id, (start, end) in enumerate(windows, 1):
    prefix = f'window-{window_id}'
    command = [str(ffmpeg), '-hide_banner', '-i', str(source), '-vf',
               f'select=between(n\\,{start}\\,{end}),showinfo,scale=1280:-2',
               '-fps_mode', 'passthrough', '-q:v', '2', str(out / (prefix + '-%03d.jpg'))]
    result = subprocess.run(command, capture_output=True)
    (out / (prefix + '-stderr.txt')).write_bytes(result.stderr)
    if result.returncode:
        raise RuntimeError('ffmpeg extraction failed')
    timestamps = [float(value) for value in re.findall(
        r'\bn:\s*\d+\s+pts:\s*\d+\s+pts_time:([\d.]+)', result.stderr.decode(errors='replace'))]
    frames = sorted(out.glob(prefix + '-[0-9][0-9][0-9].jpg'))
    assert len(frames) == len(timestamps) == end - start + 1
    sheet = Image.new('RGB', (1440, ((len(frames) + 3) // 4) * 305), '#202020')
    draw = ImageDraw.Draw(sheet)
    for index, (frame, pts) in enumerate(zip(frames, timestamps)):
        with Image.open(frame) as original:
            crop = original.crop((0, 550, 1280, 1550))
            crop.thumbnail((360, 280))
            x, y = index % 4 * 360, index // 4 * 305
            sheet.paste(crop, (x, y))
            draw.text((x + 4, y + 286), f'n={start + index} PTS={pts:.5f}s', fill='white')
        records.append({'original_frame_index': start + index, 'pts_seconds': pts,
                        'file': frame.name, 'sha256': hashlib.sha256(frame.read_bytes()).hexdigest()})
    sheet.save(out / (prefix + '-contact.jpg'), quality=95)

files = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in out.iterdir() if path.is_file()}
record = {'original_video_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'method': 'Every original decoded frame in selected windows, passthrough PTS from showinfo; no fps resampling',
          'contact_crop': [0, 550, 1280, 1550], 'selected_frames': records, 'files_sha256': files,
          'scope': 'Operator video analysis outside product; no code changes or board access'}
(out / 'extraction-record.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'frames': len(records), 'windows': windows, 'output': str(out)}))
