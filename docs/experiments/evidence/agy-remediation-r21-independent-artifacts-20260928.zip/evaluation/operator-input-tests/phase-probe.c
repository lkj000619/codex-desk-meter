#include "meter_input.h"
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

static void cleanup(meter_input_t *x) {
    if (x->queue_cs) { DeleteCriticalSection((CRITICAL_SECTION *)x->queue_cs); free(x->queue_cs); }
}
static int pulse(int duration, int phase, int two) {
    meter_input_t x; meter_input_init_default(&x);
    for (int t=0;t<600;t+=10) {
        int start=100+phase;
        int down=(t>=start && t<start+duration);
        if(two && t>=start+duration+50 && t<start+duration+50+duration) down=1;
        meter_input_feed_sample(&x,down?0:1,t);
    }
    int count=0; meter_input_event_t e;
    while(meter_input_pop_event(&x,&e)) count++;
    cleanup(&x); return count;
}
int main(void) {
    int failures=0, short30=0;
    for(int phase=0;phase<10;phase++) {
        failures += pulse(50,phase,0)!=1;
        failures += pulse(100,phase,0)!=1;
        failures += pulse(50,phase,1)!=2;
        short30 += pulse(30,phase,0);
    }
    meter_input_t x; meter_input_init_default(&x);
    for(int t=0;t<4000;t+=10) meter_input_feed_sample(&x,(t>=100 && t<3100)?0:1,t);
    meter_input_event_t e; int held=0;
    while(meter_input_pop_event(&x,&e)) held++;
    failures += held!=1; cleanup(&x);
    meter_input_init_default(&x);
    for(int t=0;t<2400;t+=10) meter_input_feed_sample(&x,(t%120<60)?0:1,t);
    int queued=0, ordered=1; long long prior=-1;
    while(meter_input_pop_event(&x,&e)) { queued++; if(e.timestamp_ms<=prior) ordered=0; prior=e.timestamp_ms; }
    failures += queued!=16 || x.events_dropped_queue_full!=4 || !ordered;
    printf("{\"failures\":%d,\"phase_offsets\":10,\"50ms_single_cases\":10,\"100ms_single_cases\":10,\"50ms_press_50ms_release_two_press_cases\":10,\"held_3s_event_count\":%d,\"queue_entries\":%d,\"queue_overflow_drops\":%u,\"fifo_ordered\":%s,\"30ms_observed_events_of_10\":%d,\"timing_scope\":\"ideal host samples; no FreeRTOS or physical LCD latency proof\"}\n",failures,held,queued,x.events_dropped_queue_full,ordered?"true":"false",short30);
    cleanup(&x); return failures?1:0;
}
