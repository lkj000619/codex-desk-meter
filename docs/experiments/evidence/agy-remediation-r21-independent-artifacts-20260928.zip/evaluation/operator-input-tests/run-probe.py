import hashlib,json,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent
c=p.parent/'checkout'
argv=['C:/Espressif/benchmark-host-tools/llvm-mingw-20260616-ucrt-x86_64/bin/cc.exe','-std=c11','-Wall','-Wextra','-I',str(c/'components/meter/include'),str(p/'phase-probe.c'),str(c/'build-host/libmeter_core.a'),'-o',str(p/'phase-probe.exe')]
build=subprocess.run(argv,capture_output=True)
(p/'compile-stdout.txt').write_bytes(build.stdout);(p/'compile-stderr.txt').write_bytes(build.stderr)
assert build.returncode==0,build.stderr.decode(errors='replace')
run=subprocess.run([str(p/'phase-probe.exe')],capture_output=True)
(p/'stdout.txt').write_bytes(run.stdout);(p/'stderr.txt').write_bytes(run.stderr)
report={'operator_product_edits':False,'compile_argv':argv,'compile_exit_code':build.returncode,'probe_exit_code':run.returncode,'result':json.loads(run.stdout),'hashes':{str(f.relative_to(p)) if f.is_relative_to(p) else str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [p/'phase-probe.c',p/'run-probe.py',c/'build-host/libmeter_core.a',c/'components/meter/meter_input.c']}}
(p/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report)); assert run.returncode==0
