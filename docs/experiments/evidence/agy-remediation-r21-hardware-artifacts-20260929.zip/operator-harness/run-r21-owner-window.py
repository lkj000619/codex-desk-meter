"""Operator session: run unchanged archived AGY CLI on existing device store."""
import datetime,hashlib,json,subprocess,sys,threading,time
from pathlib import Path
b=Path('C:/Espressif/benchmark-remediation');e=b/'evaluation-r21-20260928';c=e/'checkout';hw=b/'hardware-r21-20260929';out=hw/'owner-validation-window'
assert not out.exists();out.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8'));now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
m=read(e/'evaluation.json');store=b/'hardware-r20-20260929/actual-cli-tests/sequence-store';alias='esp32s3-288485b08518'
sys.path.insert(0,str(c/'scripts'));import host_device_pipeline as candidate
assert not candidate.PersistentSequenceStore(store).is_owner_active(alias)
argv=[sys.executable,str(c/'scripts/run-host-device-pipeline.py'),'--candidate','--device-alias',alias,'--sequence-store-dir',str(store),'--send','--port','COM3','--max-cycles','1000','--poll-interval','5','--output',str(out/'last-frame.bin')]
report={'run_id':m['run_id'],'implementation_commit':m['implementation_commit'],'operator_product_edits':False,'ranking_eligible':False,'product_pass':False,'scope':'Fixed offline fixtures. Finite1000successfulcycles at5s polling (~83min), operator timeout90min. Runs unchanged AGY CLI; no autorun installation or firmware modification. Output file observation proves host frame generation only. LCD and every device receipt require separate evidence.','argv':argv,'store_path':str(store),'initial_next_sequence':candidate.PersistentSequenceStore(store).get_current_sequence(alias),'started_at':now(),'phase':'starting','operator_timeout_seconds':5400}
stop=threading.Event();frames=[]
def monitor():
 previous=None
 while not stop.is_set():
  try:
   data=(out/'last-frame.bin').read_bytes();frame=json.loads(data)
   if frame['sequence']!=previous:
    previous=frame['sequence'];frames.append({'sequence':previous,'observed_at':now(),'sha256':hashlib.sha256(data).hexdigest()})
    (out/f'sequence-{previous}.bin').write_bytes(data)
    (out/'observed-frames.json').write_text(json.dumps(frames,indent=2)+'\n',encoding='utf-8')
  except (OSError,json.JSONDecodeError):pass
  stop.wait(0.2)
thread=threading.Thread(target=monitor);thread.start();process=None;errors=[]
try:
 with (out/'stdout.txt').open('wb') as stdout,(out/'stderr.txt').open('wb') as stderr:
  process=subprocess.Popen(argv,cwd=c,stdout=stdout,stderr=stderr)
  report.update(phase='running',sender_pid=process.pid)
  (out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
  process.wait(timeout=5400)
except Exception as exc:errors.append(repr(exc))
finally:
 if process is not None and process.poll() is None:
  process.terminate();process.wait(timeout=10)
 stop.set();thread.join()
 report.update(phase='ended',exit_code=process.returncode if process else None,errors=errors,observed_frame_count=len(frames),next_sequence=candidate.PersistentSequenceStore(store).get_current_sequence(alias),finished_at=now())
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
