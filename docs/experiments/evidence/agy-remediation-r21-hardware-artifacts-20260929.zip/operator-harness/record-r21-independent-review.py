import datetime,hashlib,json
from pathlib import Path
base=Path('C:/Espressif/benchmark-remediation');e=base/'evaluation-r21-20260928';c=e/'checkout'
root=Path.cwd();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
m=read(e/'evaluation.json');old=read(base/'evaluation-r20-20260928/evaluation.json');probe=read(e/'operator-input-tests/report.json')
assert len(m['commands'])==8 and all(x['exit_code']==0 for x in m['commands'])
assert not m['source_changes_after_build'] and probe['probe_exit_code']==0
assert all(h(c/n)==v for n,v in m['source_file_hashes'].items())
assert all(h(c/'build'/n)==v for n,v in m['binary_hashes'].items())
unchanged=['components/meter/meter_parser.c','components/meter/meter_state.c','components/meter/meter_gui.c','components/meter/meter_transport.c','components/meter/feature_imu.c','scripts/host_device_pipeline.py','scripts/run-host-device-pipeline.py']
assert all(m['source_file_hashes'][n]==old['source_file_hashes'][n] for n in unchanged)
review={
 'run_id':m['run_id'],'implementation_commit':m['implementation_commit'],'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'classification':'independent_post_run_remediation_review','ranking_eligible':False,'operator_product_edits':False,'software_flash_allowed':True,'product_pass':False,'hardware_verified':False,
 'evaluation_manifest_sha256':h(e/'evaluation.json'),'commands':m['commands'],'host_ctest_count':4,'candidate_python_test_count':25,'legacy_evaluation_case_count':29,
 'unchanged_from_r20':{n:m['source_file_hashes'][n] for n in unchanged},'binary_hashes':m['binary_hashes'],
 'input_path_review':['GPIO0 sampled in a dedicated priority6 FreeRTOS task every nominal10ms; screen drawing and IMU work are absent from the input task.','Production FSM confirms stable press, enqueues one event per held press, and rearms after release debounce. Original provider-first navigation remains unchanged.','Queued events wake the UI task. Driver bitmap transfer and IMU reads moved outside state lock; software rendering still occurs within state lock. No measured sub-millisecond lock claim adopted.'],
 'independent_input_probe':probe,
 'evidence_limits':['Ideal host sample phase sweep passed 50ms/100ms press cases at all10 millisecond phases, two50ms presses separated by50ms release, one event for3s hold, and bounded16entry FIFO overflow behavior. This does not measure physical contacts, scheduler delay, or LCD latency.','30ms pulses produced0events in10phase cases; min_press_ms is unused. Header minimum guaranteed30ms assertion is unsupported. Tested50ms envelope is conditional on nominal10ms sampling.','Two historical regression Python tests simulate the old polling logic with assumed70ms loop timing; they do not execute r20 production input or establish measured before/after hardware performance.','AGY operations document statements about100percent success, perfect debounce, sub1ms wake/lock time and guaranteed300ms response are excluded from operator conclusions.','Startup task ordering before IMU initialization and final initial draw has not been exhaustively stress-tested; boot capture will check this upload for panic markers.'],
 'physical_pending':['r21 short BOOT press reliability and debounce-to-display300ms','r21 receive-to-LCD2s','r21 basic30s LCD/three layouts','Real cable disconnect/re-enumeration and power-cycle recovery while PC sender active','Blinded lighting/50cm visibility/IMU noise/F9 owner score'],
 'live_data_scope':'Fixed fixtures only; unchanged AGY sender exists. Actual local Codex quota collector is not implemented. No live provider account data accessed.',
 'experiment_integrity':'One frozen remediation prompt; no runtime feedback; original one-shot ranking remains unchanged. Product changes and product tests are AGY authored. Operator probe is external evaluation code.'
}
(e/'operator-software-flash-gate.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(root/'docs/experiments/evidence/agy-remediation-r21-independent-review-20260928.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'software_flash_allowed':True,'product_pass':False,'commands_passed':8,'implementation_commit':m['implementation_commit'],'evaluation_manifest_sha256':review['evaluation_manifest_sha256']}))
