import contextlib,datetime,hashlib,importlib.util,io,json,subprocess,sys,time
from pathlib import Path
b=Path('C:/Espressif/benchmark-remediation');e=b/'evaluation-r21-20260928';c=e/'checkout';hw=b/'hardware-r21-20260929';out=hw/'existing-store-cli-verification'
assert not out.exists();out.mkdir()
m=json.loads((e/'evaluation.json').read_text(encoding='utf-8'))
store=b/'hardware-r20-20260929/actual-cli-tests/sequence-store';alias='esp32s3-288485b08518'
sys.path.insert(0,str(c/'scripts'));import host_device_pipeline as candidate
initial=candidate.PersistentSequenceStore(store).get_current_sequence(alias);assert initial==91
base=['--candidate','--device-alias',alias,'--sequence-store-dir',str(store),'--send','--port','COM3','--max-cycles','1']
argv=[sys.executable,str(c/'scripts/run-host-device-pipeline.py')]+base+['--output',str(out/'first-frame.bin')]
p=subprocess.run(argv,cwd=c,capture_output=True,timeout=30)
(out/'first-stdout.txt').write_bytes(p.stdout);(out/'first-stderr.txt').write_bytes(p.stderr)
assert p.returncode==0
spec=importlib.util.spec_from_file_location('operator_observed_cli',c/'scripts/run-host-device-pipeline.py');cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
events=[];log=bytearray();original=candidate.open_owner_serial
class Observed:
 def __init__(self,s):self.s=s
 def __getattr__(self,n):return getattr(self.s,n)
 def write(self,data):
  events.append({'event':'original_write','sequence':json.loads(data)['sequence'],'sha256':hashlib.sha256(data).hexdigest()});return self.s.write(data)
 def flush(self):
  result=self.s.flush();start=time.monotonic()
  while time.monotonic()-start<3:log.extend(self.s.read(4096))
  return result
 def close(self):return self.s.close()
def factory(port):
 s=original(port);events.append({'event':'original_open','dtr':s.dtr,'rts':s.rts});return Observed(s)
candidate.open_owner_serial=factory
stdout,stderr=io.StringIO(),io.StringIO()
try:
 with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):code=cli.main(base+['--output',str(out/'observed-frame.bin')])
finally:candidate.open_owner_serial=original
(out/'observed-stdout.txt').write_text(stdout.getvalue(),encoding='utf-8');(out/'observed-stderr.txt').write_text(stderr.getvalue(),encoding='utf-8');(out/'device-log.txt').write_bytes(log)
report={'run_id':m['run_id'],'implementation_commit':m['implementation_commit'],'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ranking_eligible':False,'product_pass':False,'operator_product_edits':False,'sequence_store_reinitialized':False,'store_path':str(store),'initial_next_sequence':initial,'first_unmodified_cli_argv':argv,'first_unmodified_cli_exit_code':p.returncode,'observed_cli_exit_code':code,'next_sequence':candidate.PersistentSequenceStore(store).get_current_sequence(alias),'events':events,'device_log':log.decode(errors='replace'),'scope':'Unmodified subprocess send followed by actual CLI main with original serial backend and3s passive same-stream log read. No additional port reader, reset, ACK, or product modification. Instrumented time excluded from latency. Fixed offline fixtures.'}
report['file_hashes']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in out.iterdir() if f.is_file()}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report));assert code==0
