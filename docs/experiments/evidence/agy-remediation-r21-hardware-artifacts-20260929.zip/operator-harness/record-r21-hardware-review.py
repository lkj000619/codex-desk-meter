import datetime,hashlib,json,time,zipfile
from pathlib import Path
root=Path.cwd();base=Path('C:/Espressif/benchmark-remediation');e=base/'evaluation-r21-20260928';hw=base/'hardware-r21-20260929';target=root/'docs/experiments/evidence'
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda x:hashlib.sha256(x).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
m=read(e/'evaluation.json');flash=read(hw/'flash-record.json');boot=read(hw/'boot-record.json');first=read(hw/'existing-store-cli-verification/report.json');owner=read(hw/'owner-validation-window/report.json')
assert flash['exit_code']==0 and boot['boot_elf_identity_matches'] and not boot['potential_panic_markers']
assert first['first_unmodified_cli_exit_code']==0 and first['observed_cli_exit_code']==0
assert 'Accepted cdm/1 frame seq=91' in first['device_log'] and 'Accepted cdm/1 frame seq=92' in first['device_log']
assert all(sha((e/'checkout'/n).read_bytes())==h for n,h in m['source_file_hashes'].items())
assert all(sha((e/'checkout/build'/n).read_bytes())==h for n,h in m['binary_hashes'].items())
snapshot_start=now();files={}
for f in sorted(hw.rglob('*')):
 if f.is_file():files['hardware/'+str(f.relative_to(hw)).replace('\\','/')]=f.read_bytes()
store=base/'hardware-r20-20260929/actual-cli-tests/sequence-store/esp32s3-288485b08518.json'
files['hardware/existing-store-snapshot/esp32s3-288485b08518.json']=store.read_bytes()
for name in ['verify-r21-first-send.py','run-r21-owner-window.py','record-r21-independent-review.py','record-r21-hardware-review.py','flash-verified-remediation.py']:
 files['operator-harness/'+name]=(base/name).read_bytes()
files['operator-harness/software-flash-gate.json']=(e/'operator-software-flash-gate.json').read_bytes()
snapshot_end=now();observed=json.loads(files['hardware/owner-validation-window/observed-frames.json'])
report={
 'run_id':m['run_id'],'implementation_commit':m['implementation_commit'],'classification':'post_run_hardware_verification','recorded_at':snapshot_end,'ranking_eligible':False,'product_pass':False,'operator_product_edits':False,
 'flash':flash,'boot':boot,'actual_cli_on_existing_store':first,
 'sender_window_snapshot':{'initial_report':owner,'latest_observed_sequence':observed[-1]['sequence'],'observed_frame_count':len(observed),'snapshot_started_at':snapshot_start,'snapshot_finished_at':snapshot_end,'phase_at_snapshot':owner['phase'],'note':'Sender continues after this sealed snapshot. No completed1000cycle claim; disk frame observation is not per-frame device ACK or LCD evidence. Live directory report records eventual termination.'},
 'owner_report_on_r20':{'reset_recovery':'10seconds or less, approximately3seconds while5s periodic sender active','short_boot':'Sometimes responds and sometimes does not; long or double press then quicksingle seems to advance','evidence_class':'owner statement; not synchronized timing; no claimed physical USB verification'},
 'physical_pending':['r21 BOOT reliability and300ms display response','r21 receive-to-LCD2s','r21 basic30s LCD and3layout check','Actual USB power-cycle and powered cable disconnect/re-enumeration recovery','Blinded50cm lighting/visibility and G1-G6/F9/IMU-noise judgment'],
 'physical_request_sent':'35s whole-LCD recording,5 separate shortBOOT presses,1long hold, RST then USB disconnect/reconnect. Provider changes can retain page number. USB removal without separate supply is power-cycle evidence only.',
 'source_and_binary_hashes_unchanged_since_evaluation':True,'live_account_source_implemented':False,'data_scope':'Original fixed offline provider fixtures',
 'archive_note':'Raw hardware records and running sender output captured as a bounded immutable snapshot. Prior archives preserved.'
}
reviewname='agy-remediation-r21-hardware-review-20260929.json';reviewbytes=(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode('utf-8');(target/reviewname).write_bytes(reviewbytes);files['operator-review/'+reviewname]=reviewbytes
archive=target/'agy-remediation-r21-hardware-artifacts-20260929.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:assert all(sha(z.read(n))==sha(data) for n,data in files.items())
receipt={'run_id':m['run_id'],'implementation_commit':m['implementation_commit'],'classification':'sealed_hardware_snapshot','ranking_eligible':False,'product_pass':False,'operator_product_edits':False,'archive_file':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'snapshot_started_at':snapshot_start,'snapshot_finished_at':snapshot_end,'sender_was_running':owner['phase']=='running','archive_entries':{n:sha(data) for n,data in sorted(files.items())}}
archive.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'flash_verified':True,'accepted_sequences':[91,92],'owner_sender_pid':owner.get('sender_pid'),'snapshot_latest_sequence':observed[-1]['sequence'],'archive_sha256':receipt['archive_sha256'],'archive_entries':len(files),'product_pass':False}))
