import hashlib
import json
import re
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw

base = Path('C:/Espressif/benchmark-remediation/hardware-r21-20260929')
source = base / 'user-media-02/video.mp4'
out = base / 'finger-timing-review-20260929'
out.mkdir(exist_ok=True)
ffmpeg = Path('C:/Espressif/tmp/codex-video-tools/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe')
windows = [(45, 96), (108, 144), (144, 180)]
records = []
commands = []
for window_id, (start, end) in enumerate(windows, 1):
    prefix = f'window-{window_id}'
    command = [str(ffmpeg), '-hide_banner', '-i', str(source), '-vf',
               f'select=between(n\\,{start}\\,{end}),showinfo,scale=1280:-2',
               '-fps_mode', 'passthrough', '-q:v', '2', str(out / (prefix + '-%03d.jpg'))]
    commands.append(command)
    result = subprocess.run(command, capture_output=True)
    (out / (prefix + '-stderr.txt')).write_bytes(result.stderr)
    assert result.returncode == 0
    times = [float(x) for x in re.findall(r'\bn:\s*\d+\s+pts:\s*\d+\s+pts_time:([\d.]+)', result.stderr.decode(errors='replace'))]
    frames = sorted(out.glob(prefix + '-[0-9][0-9][0-9].jpg'))
    assert len(frames) == len(times) == end - start + 1
    for index, (frame, pts) in enumerate(zip(frames, times)):
        records.append({'original_frame_index': start + index, 'pts_seconds': pts,
                        'file': frame.name, 'sha256': hashlib.sha256(frame.read_bytes()).hexdigest()})
    for first in range(0, len(frames), 16):
        group = list(zip(frames, times))[first:first + 16]
        sheet = Image.new('RGB', (1600, ((len(group) + 3) // 4) * 365), '#202020')
        draw = ImageDraw.Draw(sheet)
        for j, (frame, pts) in enumerate(group):
            with Image.open(frame) as original:
                crop = original.crop((0, 900, 1280, 1950))
                crop.thumbnail((400, 340))
                x, y = j % 4 * 400, j // 4 * 365
                sheet.paste(crop, (x, y))
                draw.text((x + 4, y + 345), f'n={start + first + j} PTS={pts:.5f}s', fill='white')
        sheet.save(out / f'{prefix}-contact-{first//16+1}.jpg', quality=95)

record = {'original_video_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'method': 'Continuous original frames selected without fps resampling; PTS from FFmpeg showinfo',
          'commands': commands, 'contact_crop': [0, 900, 1280, 1950],
          'selected_frames': records, 'files_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                                      for p in out.iterdir() if p.is_file()}}
(out / 'extraction-record.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'frames': len(records), 'output': str(out)}))
